<?php
  session_start();
  include('modulo/conexion.php');
  include('modulo/validar.php');

  $id = $_SESSION['xID'];
  $nombre = $_SESSION['xNombre'];
  $apellido = $_SESSION['xApellido'];
  $usuario = $nombre." ".$apellido;
 
?>
<?php 	include('includes/header.php');
		
 ?>
<div class="d-flex" id="content-wrapper">
    <?php include('includes/sidebar.php'); ?>
    <!-- Page Content -->
    <div id="content" class="bg-grey w-100">
        <section class="bg-light py-3">
            <div class="container">
			<?php include('includes/tables/table_evaluacion.php'); ?>
                <div class="row">
                    <div class="col-lg-3 col-md-4 d-flex">
                        <a data-toggle="modal" data-target="#view-modal" class="btn btn-primary w-100 align-self-center" href="#">Descargar reporte</a>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<!-- Inicio Modal -->
<div class="modal fade" id="view-modal">
	<div class="modal-dialog ">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Preparando Reporte...</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<div class="show-info modal-body">
				<form  action="" method="POST">
					<div class="card-body">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="name">Fecha inicial de captura</label><br>
									<input required type="date" id="fecha1" name="fecha1">
								</div>
							</div>
						</div>
					
					
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="name">Fecha final de captura</label><br>
									<input required type="date"id="fecha2" name="fecha2">
								</div>
							</div>
						</div>
					
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<a onclick="downForm();" class="btn btn-primary btn-sm form-control" href="#">Descargar</a>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- Fin Modal -->
<script src="assets/plugins/html2pdf.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.70/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.70/vfs_fonts.js"></script>
<script type="text/javascript">

function downForm(fecha1, fecha2) {
    fecha1 = $('#fecha1').val();
    fecha2 = $('#fecha2').val();

    if (fecha1 == "" || fecha2 == "") {
        toastr.warning('Las fechas no pueden estar vacías');
    } else {
        // Array con URLs para diferentes sets de datos
        const urls = [
            'reportes/pdf_fechas.php',
            'reportes/pdf_evaluacion.php',
            'reportes/Artículos indizados en JCR.php',
            'reportes/Artículos en Otros Índices.php',
            'reportes/Artículos de Divulgación.php',
            'reportes/Capítulos de Libro.php',
            'reportes/Congresos Internacionales y Nacionales.php',
            'reportes/Proyectos Concluidos.php',
            'reportes/Proyectos Vigentes.php',
            'reportes/pdf_estancias.php',
            'reportes/pdf_formacion.php',
            'reportes/pdf_organizacion.php',
            'reportes/pdf_plan.php',
            'reportes/pdf_necesidad.php',
        ];

        // Array para almacenar los datos de cada solicitud
        const dataSets = [];

        // Función para realizar una solicitud AJAX por URL
        function fetchData(url, fecha1, fecha2) {
            return $.ajax({
                type: 'POST',
                url: url,
                data: { fecha1: fecha1, fecha2: fecha2 },
            });
        }

        // Realizar las solicitudes en paralelo
        Promise.all(urls.map(url => fetchData(url, fecha1, fecha2)))
            .then(async responses => {
                // Almacenar los datos de cada respuesta en el array dataSets
                responses.forEach(data => dataSets.push(data));

                try {
                    // Crear el docDefinition para un solo PDF usando los datos combinados
                    const docDefinition = {
                        content:  [
                            { text: 'Reporte de actividades de los profesores de LabTec2', style: 'header' },
                            { text: dataSets[0], style:'fechatxt' }, // Segundo conjunto de datos
                            { text: 'Índices de Evaluación e Impacto de la Calidad Investigadora', style: 'boldText' },
                            { text: dataSets[1], style:'normalText' }, // Primer conjunto de datos
                            { text: 'Publicaciones', style: 'boldText',pageBreak: 'before' },
                            { text: '\n' },
                            { text: 'Artículos indizados en JCR', style: 'boldText',},
                            { text: dataSets[2], style:'normalText' }, // Primer conjunto de datos
                            { text: '\n' },
                            { text: 'Artículos en Otros Índices', style: 'boldText', },
                            { text: dataSets[3], style:'normalText' }, // Primer conjunto de datos
                            { text: '\n' },
                            { text: 'Artículos de Divulgación', style: 'boldText', },
                            { text: dataSets[4], style:'normalText' }, // Primer conjunto de datos
                            { text: '\n' },
                            { text: 'Capítulos de Libro', style: 'boldText', },
                            { text: dataSets[5], style:'normalText' }, // Primer conjunto de datos
                            { text: 'Congresos Internacionales y Nacionales', style: 'boldText', },
                            { text: dataSets[6], style:'normalText' }, // Primer conjunto de datos
                            { text: 'Proyectos con/sin financiamiento', style: 'boldText',pageBreak: 'before' },
                            { text: '\n' },
                            { text: 'Proyectos Concluidos', style: 'boldText', },
                            { text: dataSets[7], style:'normalText' }, // Primer conjunto de datos
                            { text: '\n' },
                            { text: 'Proyectos Vigentes', style: 'boldText', },
                            { text: dataSets[8], style:'normalText' }, // Primer conjunto de datos
                            { text: 'Estancias Académicas', style: 'boldText',pageBreak: 'before' },
                            { text: dataSets[9], style:'normalText' }, // Primer conjunto de datos
                            { text: 'Formación de Recursos Humanos', style: 'boldText',pageBreak: 'before' },
                            { text: '\n' },
                            { text: dataSets[10], style:'normalText' }, // Primer conjunto de datos
                            { text: 'Organización de Actividades', style: 'boldText',pageBreak: 'before' },
                            { text: dataSets[11], style:'normalText' }, // Primer conjunto de datos
                            { text: 'Plan de Trabajo', style: 'boldText',pageBreak: 'before' },
                            { text: dataSets[12], style:'normalText' }, // Primer conjunto de datos
                            { text: 'Necesidad de fortalecimiento de infraestructura', style: 'boldText',pageBreak: 'before' },
                            { text: dataSets[13], style:'normalText' }, // Primer conjunto de datos
                            ],
                        styles: {
                            header: {
                                fontSize: 22,
                                bold: true,
                                color: 'blue',
                                alignment: 'center'
                            },
                            fechatxt: {
                                fontSize: 16,
                                bold: true,
                                alignment: 'center'
                            },
                            boldText: {
                                fontSize: 14,
                                bold: true
                            },
                            normalText: {
                                fontSize: 12
                            },
                        }
                    };

                    // Generar el PDF con pdfMake
                    pdfMake.createPdf(docDefinition).download('Reporte general.pdf');
                } catch (error) {
                    console.error('Error generating PDF:', error);
                }
            })
            .catch(error => {
                console.error('Error in AJAX requests:', error);
            });
    }
}

$( document ).ready(function() {
     $('#evaluacion').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true,
      "responsive": true
    })
    });
	DataTable('#evaluacion', {
    layout: {
        topStart: {
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
        }
    }
});
</script>
<?php include('includes/footer.php'); ?>