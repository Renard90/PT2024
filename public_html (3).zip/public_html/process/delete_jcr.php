<?php
include('../modulo/conexion.php');

$id_jcr = $_POST['id_jcr'];


$query = "DELETE FROM tbl_publicaciones_jcr WHERE id_jcr = '$id_jcr';";
$result = mysqli_query($conexion,$query);


?>
<script>	
    window.location.href = "../index.php";
</script>