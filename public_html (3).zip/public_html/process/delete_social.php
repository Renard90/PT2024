<?php
include('../modulo/conexion.php');

$id_servicio = $_POST['id_social'];


$query = "DELETE FROM tbl_servicio_actividad WHERE id_servicio = '$id_servicio'";
$result = mysqli_query($conexion,$query);

?>

<script>	
    window.location.href = "../index.php";
</script>