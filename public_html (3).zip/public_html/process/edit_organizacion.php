<?php
include('../modulo/conexion.php');

$id_organizacion = $_POST['id_organizacion'];
$nombre = utf8_encode($_POST['nombre']);
$proyecto = utf8_encode($_POST['proyecto']);
$inicio = $_POST['inicio'];
$fin = $_POST['fin'];
$institucion = utf8_encode($_POST['institucion']);

$query = "UPDATE tbl_organizacion SET nombre = '$nombre', proyecto = '$proyecto', inicio = '$inicio', fin = '$fin', institucion = '$institucion' WHERE id_organizacion = '$id_organizacion';";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>