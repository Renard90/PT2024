<?php
include('../modulo/conexion.php');

$id_jcr = $_POST['id_jcr'];
$nombre = utf8_encode($_POST['nombre']);
$autores = utf8_encode($_POST['autores']);
$paginas = $_POST['paginas'];
$revista = utf8_encode($_POST['revista']);
$issn = $_POST['issn'];
$issn_electronico = $_POST['issn_electronico'];
$publicacion = $_POST['publicacion'];
$doi = base64_encode($_POST['doi']);
$link = base64_encode($_POST['link']);

$query = "UPDATE tbl_publicaciones_jcr SET nombre = '$nombre', autores = '$autores', paginas = '$paginas', revista = '$revista', issn = '$issn',issn_electronico = '$issn_electronico', publicacion = '$publicacion', doi = '$doi', link = '$link' WHERE id_jcr = '$id_jcr';";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>