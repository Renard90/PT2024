<?php
include('../modulo/conexion.php');

$id_necesidad = $_POST['id_necesidad'];
$necesidad = base64_encode($_POST['necesidad']);

$query = "UPDATE tbl_necesidad SET necesidad = '$necesidad' WHERE id_necesidad = '$id_necesidad';";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>