<?php
include('../modulo/conexion.php');

$necesidad = base64_encode($_POST['necesidad']);
$usuario = utf8_encode($_POST['usuario']);

$query = "INSERT INTO tbl_necesidad (`necesidad`, `fecha`, `usuario`) VALUES ('$necesidad', CURRENT_TIME(), '$usuario')";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>