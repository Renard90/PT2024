<?php
include('../modulo/conexion.php');

$proyecto = utf8_encode($_POST['proyecto']);
$nombre = utf8_encode($_POST['nombre']);
$autores = utf8_encode($_POST['autores']);
$inicio = $_POST['inicio'];
$fin = $_POST['fin'];
$institucion = utf8_encode($_POST['institucion']);
$estado = utf8_encode($_POST['estado']);
$usuario = utf8_encode($_POST['usuario']);

$query = "INSERT INTO tbl_proyectos_concluidos (`proyecto`,`nombre`,`autores`,`fecha_inicio`,`fecha_fin`,`institucion`,`estado`,`fecha`,`usuario`) VALUES ('$proyecto','$nombre','$autores','$inicio','$fin','$institucion','$estado
', CURRENT_TIME(), '$usuario')";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>