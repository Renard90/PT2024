<script>
$(function(alerta(a)){function(e){ 
e.preventDefault();
toastr.options = {
  "positionClass": "toast-top-center",
  "timeOut": "1500",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut"
}
     function(a)
     {
      console.log(a);
          if (a==1) {
          toastr.success('Informacion actualizada correctamente!');		  
		  setTimeout("redirectFunc()", 2000);
		  }
         if (a!=1) {
            console.log(a);
            toastr.error('¡Hubo un error!10 Intente de nuevo');
			$('#actualizar').trigger("reset");
		}}};})	;

</script>
