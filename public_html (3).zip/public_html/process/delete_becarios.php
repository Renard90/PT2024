<?php
include('../modulo/conexion.php');

$id_becarios = $_POST['id_becarios'];


$query = "DELETE FROM tbl_becarios WHERE id_becarios = '$id_becarios'";
$result = mysqli_query($conexion,$query);


?>

<script>	
    window.location.href = "../index.php";
</script>