<?php
include('../modulo/conexion.php');

$id_evaluacion = $_POST['id_evaluacion'];


$query = "DELETE FROM tbl_evaluacion WHERE id_evaluacion = '$id_evaluacion'";
$result = mysqli_query($conexion,$query);

?>
<script>	
    window.location.href = "../index.php";
</script>