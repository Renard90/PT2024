<?php
include('../modulo/conexion.php');

$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$correo = $_POST['correo'];
$password = sha1($_POST['password']);
$pass1 = $_POST['password'];
$pass2 = $_POST['password2'];

if(buscarRepetido($correo, $conexion	) == 1){
  echo 2;
}else if ( passwordscoinciden($pass1,$pass2)== 0) {
  echo 3;	
}else{
  $query = "INSERT INTO tbl_usuario (`nombre`,`apellido`,`correo`, `password`) VALUES ('$nombre','$apellido','$correo', '$password')";
  $result = mysqli_query($conexion,$query);
}

function passwordscoinciden($pass1,$pass2){
	if ($pass1==$pass2){
		return 1;
	}else {
		return 0;
	}
	
}


function buscarRepetido($correo, $conexion){
  $query = "SELECT * FROM tbl_usuario WHERE correo = '$correo'";
  $result = mysqli_query($conexion,$query);
  if(mysqli_num_rows($result) > 0){
    return 1;
  }else{
    return 0;
  }
}

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>