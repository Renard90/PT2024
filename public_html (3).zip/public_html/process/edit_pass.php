<?php
include('../modulo/conexion.php');

$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$correo = $_POST['correo'];
$password = sha1($_POST['password']);

$query = "UPDATE tbl_usuario SET password = '$password' WHERE nombre = '$nombre', apellido = '$apellido', correo = '$correo';";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>