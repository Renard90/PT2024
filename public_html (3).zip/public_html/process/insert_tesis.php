<?php
include('../modulo/conexion.php');

$tipo = utf8_encode($_POST['tipo']);
$nombre = utf8_encode($_POST['nombre']);
$autor = utf8_encode($_POST['autor']);
$fecha_tesis = utf8_encode($_POST['fecha_tesis']);
$institucion = utf8_encode($_POST['institucion']);
$programa = utf8_encode($_POST['programa']);
$estado = utf8_encode($_POST['estado']);
$usuario = utf8_encode($_POST['usuario']);

$query = "INSERT INTO tbl_tesis (`tipo`,`nombre`,`autor`,`fecha_tesis`,`institucion`,`programa`,`estado`,`fecha`,`usuario`) VALUES ('$tipo','$nombre','$autor','$fecha_tesis','$institucion','$programa','$estado', CURRENT_TIME(), '$usuario')";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>