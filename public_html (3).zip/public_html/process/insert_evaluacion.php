<?php
include('../modulo/conexion.php');

$actividad = base64_encode($_POST['actividad']);
$usuario = utf8_encode($_POST['usuario']);

$query = "INSERT INTO tbl_evaluacion (`actividad`, `fecha`, `usuario`) VALUES ('$actividad', CURRENT_TIME(), '$usuario')";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>