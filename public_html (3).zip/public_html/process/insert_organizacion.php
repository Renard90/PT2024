<?php
include('../modulo/conexion.php');

$nombre = utf8_encode($_POST['nombre']);
$proyecto = utf8_encode($_POST['proyecto']);
$inicio = $_POST['inicio'];
$fin = $_POST['fin'];
$institucion = utf8_encode($_POST['institucion']);
$usuario = utf8_encode($_POST['usuario']);

$query = "INSERT INTO tbl_organizacion (`nombre`,`proyecto`,`inicio`,`fin`,`institucion`,`fecha`,`usuario`) VALUES ('$nombre','$proyecto','$inicio','$fin','$institucion', CURRENT_TIME(),'$usuario')";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>