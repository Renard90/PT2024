<?php
include('../modulo/conexion.php');

$plan = base64_encode($_POST['plan']);
$inicio = $_POST['inicio'];
$fin = $_POST['fin'];
$usuario = utf8_encode($_POST['usuario']);

$query = "INSERT INTO tbl_plan (`plan`,`inicio`,`fin`,`fecha`,`usuario`) VALUES ('$plan','$inicio','$fin', CURRENT_TIME(), '$usuario')";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>