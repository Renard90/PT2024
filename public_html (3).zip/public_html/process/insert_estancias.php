<?php
include('../modulo/conexion.php');

$nombre = utf8_encode($_POST['nombre']);
$proyecto = utf8_encode($_POST['proyecto']);
$autores = utf8_encode($_POST['autores']);
$institucion = utf8_encode($_POST['institucion']);
$estancias = utf8_encode($_POST['estancias']);
$usuario = utf8_encode($_POST['usuario']);

$query = "INSERT INTO tbl_estancias (`nombre`,`proyecto`,`autores`,`institucion`,`estancias`, `fecha`, `usuario`) VALUES ('$nombre','$proyecto','$autores','$institucion','$estancias', CURRENT_TIME(), '$usuario')";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>