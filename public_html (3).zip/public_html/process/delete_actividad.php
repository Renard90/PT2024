<?php
include('../modulo/conexion.php');

$id_servicio = $_POST['id_actividad'];


$query = "DELETE FROM tbl_servicio_actividad WHERE id_servicio = '$id_servicio'";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}
?>