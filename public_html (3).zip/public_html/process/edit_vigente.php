<?php
include('../modulo/conexion.php');

$id_vigente = $_POST['id_vigente'];
$proyecto = utf8_encode($_POST['proyecto']);
$nombre = utf8_encode($_POST['nombre']);
$autores = utf8_encode($_POST['autores']);
$fecha_inicio = $_POST['fecha_inicio'];
$fecha_fin = $_POST['fecha_fin'];
$institucion = utf8_encode($_POST['institucion']);


$query = "UPDATE tbl_proyectos_vigente SET proyecto = '$proyecto', nombre = '$nombre', autores = '$autores', fecha_inicio = '$fecha_inicio', fecha_fin = '$fecha_fin', institucion = '$institucion' WHERE id_vigente = '$id_vigente';";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}
?>
