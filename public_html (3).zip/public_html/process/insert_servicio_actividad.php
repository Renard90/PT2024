<?php
include('../modulo/conexion.php');

$tipo = utf8_encode($_POST['tipo']);
$nombre = utf8_encode($_POST['nombre']);
$proyecto = utf8_encode($_POST['proyecto']);
$programa = utf8_encode($_POST['programa']);
$inicio = $_POST['inicio'];
$fin = $_POST['fin'];
$usuario = utf8_encode($_POST['usuario']);

$query = "INSERT INTO tbl_servicio_actividad (`tipo`,`nombre`,`proyecto`,`programa`,`inicio`,`fin`,`fecha`,`usuario`) VALUES ('$tipo','$nombre','$proyecto','$programa','$inicio','$fin', CURRENT_TIME(), '$usuario')";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>