<?php
include('../modulo/conexion.php');

$id_concluidos = $_POST['id_concluidos'];


$query = "DELETE FROM tbl_proyectos_concluidos WHERE id_concluidos = '$id_concluidos';";
$result = mysqli_query($conexion,$query);


?>
<script>	
    window.location.href = "../index.php";
</script>