<?php
include('../modulo/conexion.php');


$id_publicaciones = $_POST['id_publicaciones'];
$tipo = utf8_encode($_POST['tipo']);
$nombre = utf8_encode($_POST['nombre']);
$autores = utf8_encode($_POST['autores']);
$paginas = $_POST['paginas'];
$publicacion = $_POST['publicacion'];
$lugar = utf8_encode($_POST['lugar']);
$link = base64_encode($_POST['link']);

$query = "UPDATE tbl_publicaciones SET tipo = '$tipo', nombre = '$nombre', autores = '$autores', paginas = '$paginas', publicacion = '$publicacion', lugar = '$lugar', link = '$link' WHERE id_publicaciones = '$id_publicaciones';";
$result = mysqli_query($conexion,$query);
return $result;
?>
</body>
</html>




