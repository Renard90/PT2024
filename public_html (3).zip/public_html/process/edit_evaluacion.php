<?php
include('../modulo/conexion.php');

$id_evaluacion = $_POST['id_evaluacion'];
$actividad = base64_encode($_POST['actividad']);

$query = "UPDATE tbl_evaluacion SET actividad = '$actividad' WHERE id_evaluacion = '$id_evaluacion'";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>
