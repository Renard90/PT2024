<?php
include('../modulo/conexion.php');

$id_plan = $_POST['id_plan'];


$query = "DELETE FROM tbl_plan WHERE id_plan = '$id_plan'";
$result = mysqli_query($conexion,$query);

?>
<script>	
    window.location.href = "../index.php";
</script>