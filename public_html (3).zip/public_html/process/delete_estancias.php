<?php
include('../modulo/conexion.php');

$id_estancias = $_POST['id_estancias'];


$query = "DELETE FROM tbl_estancias WHERE id_estancias = '$id_estancias'";
$result = mysqli_query($conexion,$query);

?>

<script>	
    window.location.href = "../index.php";
</script>