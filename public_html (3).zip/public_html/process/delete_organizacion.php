<?php
include('../modulo/conexion.php');

$id_organizacion = $_POST['id_organizacion'];


$query = "DELETE FROM tbl_organizacion WHERE id_organizacion = '$id_organizacion'";
$result = mysqli_query($conexion,$query);

?>
<script>	
    window.location.href = "../index.php";
</script>