<?php
include('../modulo/conexion.php');

$id_vigente = $_POST['id_vigente'];


$query = "DELETE FROM tbl_proyectos_vigente WHERE id_vigente = '$id_vigente';";
$result = mysqli_query($conexion,$query);


?>
<script>	
    window.location.href = "../index.php";
</script>