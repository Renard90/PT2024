<?php
include('../modulo/conexion.php');

$nombre = utf8_encode($_POST['nombre']);
$autores = utf8_encode($_POST['autores']);
$paginas = $_POST['paginas'];
$revista = utf8_encode($_POST['revista']);
$issn = $_POST['issn'];
$issn_electronico = $_POST['issn_electronico'];
$publicacion = $_POST['publicacion'];
$doi = base64_encode($_POST['doi']);
$link = base64_encode($_POST['link']);
$usuario = utf8_encode($_POST['usuario']);

$query = "INSERT INTO tbl_publicaciones_jcr (`nombre`, `autores`,`paginas`,`revista`,`issn`,`issn_electronico`,`publicacion`,`doi`,`link`,`fecha`,`usuario`) VALUES ('$nombre','$autores','$paginas','$revista','$issn','$issn_electronico','$publicacion','$doi','$link', CURRENT_TIME(), '$usuario')";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>