<?php
include('../modulo/conexion.php');

$id_plan = $_POST['id_plan'];
$plan = base64_encode($_POST['plan']);
$inicio = $_POST['inicio'];
$fin = $_POST['fin'];

$query = "UPDATE tbl_plan SET plan = '$plan', inicio = '$inicio', fin = '$fin' WHERE id_plan = '$id_plan';";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}
?>
