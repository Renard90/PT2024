<?php
include('../modulo/conexion.php');

$id_tesis = $_POST['id_tesis'];


$query = "DELETE FROM tbl_tesis WHERE id_tesis = '$id_tesis';";
$result = mysqli_query($conexion,$query);


?>
<script>	
    window.location.href = "../index.php";
</script>