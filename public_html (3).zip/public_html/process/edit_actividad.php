<?php
include('../modulo/conexion.php');

$id_servicio = $_POST['id_actividad'];
$nombre = utf8_encode($_POST['nombre']);
$proyecto = utf8_encode($_POST['proyecto']);
$programa = utf8_encode($_POST['programa']);
$inicio = $_POST['inicio'];
$fin = $_POST['fin'];

$query = "UPDATE tbl_servicio_actividad SET nombre = '$nombre', proyecto = '$proyecto', programa = '$programa', inicio = '$inicio', fin = '$fin' WHERE id_servicio = '$id_servicio';";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}
?>
