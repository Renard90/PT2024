<?php
include('../modulo/conexion.php');

$nombre = utf8_encode($_POST['nombre']);
$proyecto = utf8_encode($_POST['proyecto']);
$inicio = utf8_encode($_POST['inicio']);
$fin = utf8_encode($_POST['fin']);
$usuario = utf8_encode($_POST['usuario']);

$query = "INSERT INTO tbl_becarios (`nombre`,`proyecto`,`inicio`,`fin`,`fecha`,`usuario`) VALUES ('$nombre','$proyecto','$inicio','$fin', CURRENT_TIME(), '$usuario')";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>