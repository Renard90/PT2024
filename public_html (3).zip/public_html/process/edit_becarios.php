<?php
include('../modulo/conexion.php');

$id_becarios = $_POST['id_becarios'];
$nombre = utf8_encode($_POST['nombre']);
$proyecto = utf8_encode($_POST['proyecto']);
$inicio = utf8_encode($_POST['inicio']);
$fin = utf8_encode($_POST['fin']);

$query = "UPDATE tbl_becarios SET nombre = '$nombre', proyecto = '$proyecto', inicio = '$inicio', fin = '$fin' WHERE id_becarios = '$id_becarios';";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}
?>
