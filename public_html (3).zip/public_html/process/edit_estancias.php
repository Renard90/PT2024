<?php
include('../modulo/conexion.php');

$id_estancias = $_POST['id_estancias'];
$nombre = utf8_encode($_POST['nombre']);
$proyecto = utf8_encode($_POST['proyecto']);
$autores = utf8_encode($_POST['autores']);
$institucion = utf8_encode($_POST['institucion']);
$estancias = utf8_encode($_POST['estancias']);

$query = "UPDATE tbl_estancias SET nombre = '$nombre', proyecto = '$proyecto', autores = '$autores', institucion = '$institucion', estancias = '$estancias' WHERE id_estancias = '$id_estancias';";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>