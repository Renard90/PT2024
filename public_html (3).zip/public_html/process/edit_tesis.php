<?php
include('../modulo/conexion.php');

$id_tesis = $_POST['id_tesis'];
//$tipo = utf8_encode($_POST['tipo']);
$nombre = utf8_encode($_POST['nombre']);
$autor = utf8_encode($_POST['autor']);
$fecha_tesis = utf8_encode($_POST['fecha_tesis']);
$institucion = utf8_encode($_POST['institucion']);
$programa = utf8_encode($_POST['programa']);
$estado = utf8_encode($_POST['estado']);

$query = "UPDATE tbl_tesis SET nombre = '$nombre', autor = '$autor', fecha_tesis = '$fecha_tesis', institucion = '$institucion', programa = '$programa', estado = '$estado' WHERE id_tesis = '$id_tesis';";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}
?>