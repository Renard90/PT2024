<?php
include('../modulo/conexion.php');

$id_concluidos = $_POST['id_concluidos'];
$proyecto = utf8_encode($_POST['proyecto']);
$nombre = utf8_encode($_POST['nombre']);
$autores = utf8_encode($_POST['autores']);
$inicio = $_POST['inicio'];
$fin = $_POST['fin'];
$institucion = utf8_encode($_POST['institucion']);


$query = "UPDATE tbl_proyectos_concluidos SET proyecto = '$proyecto', nombre = '$nombre', autores = '$autores', fecha_inicio = '$inicio', fecha_fin = '$fin', institucion = '$institucion' WHERE id_concluidos = '$id_concluidos';";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}
?>

