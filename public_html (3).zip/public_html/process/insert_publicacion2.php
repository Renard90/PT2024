<?php
include('../modulo/conexion.php');

$tipo = utf8_encode($_POST['tipo']);
$nombre = utf8_encode($_POST['nombre']);
$autores = utf8_encode($_POST['autores']);
$paginas = $_POST['paginas'];
$issn = $_POST['issn'];
$publicacion = $_POST['publicacion'];
$lugar = utf8_encode($_POST['lugar']);
$link = base64_encode($_POST['link']);
$usuario = utf8_encode($_POST['usuario']);

$query = "INSERT INTO tbl_publicaciones (`tipo`,`nombre`,`autores`,`paginas`,`issn`,`publicacion`,`lugar`,`link`,`fecha`,`usuario`) VALUES ('$tipo','$nombre','$autores','$paginas','$issn','$publicacion','$lugar','$link', CURRENT_TIME(),'$usuario')";
$result = mysqli_query($conexion,$query);

if ($result) {
  echo "true";
}else{
  echo mysqli_error($conexion);
}

?>