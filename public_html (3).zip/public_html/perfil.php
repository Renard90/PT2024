<?php
  session_start();
  include('modulo/conexion.php');
  include('modulo/validar.php');

    $id = $_SESSION['xID'];
    $consulta = "SELECT * FROM tbl_usuario WHERE id = '$id';";
    $resultado = mysqli_query($conexion,$consulta);
    $rows = mysqli_fetch_array($resultado);
    $Nombre = utf8_decode($rows['nombre']);
    $Apellido = utf8_decode($rows['apellido']);
    $Correo = utf8_decode($rows['correo']);
    
?>
<?php include('includes/header.php'); ?>
<div class="d-flex" id="content-wrapper">
  <?php include('includes/sidebar.php'); ?>
  <!-- Page Content -->
  <div id="content" class="bg-grey w-100">
    <section class="bg-light py-3">
      <div class="container">
        <div class="row">
          <div class="col-lg-9 col-md-8">
            <h1 class="font-weight-bold mb-0">Mi Perfil</h1>
          </div>
        </div>
      </div>
    </section>
    <!-- Organización de Actividades -->
    <section>
      <div class="container">
        <div class="row">
          <!-- Margen anchura del cuadro FORM -->
          <div class="col-lg-8 my-3">
            <!-- Margen del cuadro FORM -->
            <div class="card rounded-0">
              <div class="card-header bg-light">
                <h6 class="font-weight-bold mb-0">Mis Datos</h6>
              </div>
              <div class="card-body">
                <!-- Formulario -->
                <form id="edituser" action="process/edit_perfil.php" method="POST">
                  <div class="form-group">
                  <input type="hidden" name="id" value="<?php echo $id;?>">
                    <label for="inputAddress">Nombre</label>
                    <input type="text" name="nombre" class="form-control" id="inputAddress" value="<?php echo $Nombre;?>">
                  </div>
                  <div class="form-group">
                    <label for="inputAddress">Apellido</label>
                    <input type="text" name="apellido" class="form-control" id="inputAddress" value="<?php echo $Apellido;?>">
                  </div>
                  <div class="form-group">
                    <label for="inputAddress">E-Mail</label>
                    <input type="text" name="correo" class="form-control" id="inputAddress" value="<?php echo $Correo;?>">
                  </div>
                  <div class="form-group">
                    <label for="inputAddress">Password</label>
                    <input type="password"  required name="password" class="form-control" id="inputAddress" placeholder="Ingrese su contraseña o ingrese una nueva">
                  </div>
                  <button type="submit" class="btn btn-primary">Editar</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>
<?php include('includes/footer.php'); ?>