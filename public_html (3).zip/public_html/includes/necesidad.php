<?php
  session_start();
  include('modulo/conexion.php');
  include('modulo/validar.php');

  $id = $_SESSION['xID'];
  $nombre = $_SESSION['xNombre'];
  $apellido = $_SESSION['xApellido'];
  $usuario = $nombre." ".$apellido;
?>
<?php include('includes/header.php'); ?>
<div class="d-flex" id="content-wrapper">
  <?php include('includes/sidebar.php'); ?>
  <!-- Page Content -->
  <div id="content" class="bg-grey w-100">
    <section class="bg-light py-3">
      <div class="container">
        <div class="row">
          <div class="col-lg-9 col-md-8">
            <h1 class="font-weight-bold mb-0"> Necesidad de fortalecimiento de infraestructura</h1>
          </div>
          <div class="col-lg-3 col-md-4 d-flex">
            <a data-toggle="modal" data-target="#view-modal" class="btn btn-primary w-100 align-self-center" href="#">Descargar reporte</a>
          </div>
        </div>
      </div>
    </section>
    <section>
      <div class="container">
        <div class="row">
          <!-- Margen anchura del cuadro FORM -->
          <div class="col-lg-10 my-3">
            <!-- Margen del cuadro FORM -->
            <div class="card rounded-0">
              <div class="card-header bg-light">
                <h6 class="font-weight-bold mb-0">En este apartado puede incluir información de alguna necesidad prioritaria para la operación del laboratorio  </h6>
              </div>
              <div class="card-body">
                <!-- Formulario -->
                <form id="insert" action="process/insert_necesidad.php" method="POST">
				<input type="hidden" value="<?php echo $usuario; ?>" name="usuario">
                  <div class="form-group">
                    <label for="exampleFormControlTextarea1"> Necesidades prioritarias para la operación del
                      laboratorio</label>
                    <textarea class="form-control" required name="necesidad" placeholder="Solicitudes de equipo especializado, moviliario, licencias de software o infraestructura que se necesitan" id="exampleFormControlTextarea1" rows="3"></textarea>
                  </div>
                  <button type="submit" class="btn btn-primary">Done</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>
<!-- Inicio Modal -->
<div class="modal fade" id="view-modal">
	<div class="modal-dialog ">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Preparando Reporte...</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<div class="show-info modal-body">
				<form  action="" method="POST">
					<div class="card-body">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="name">Fecha inicial de captura</label><br>
									<input required type="date" id="fecha1" name="fecha1">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="name">Fecha final de captura</label><br>
									<input required type="date"id="fecha2" name="fecha2">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<a onclick="downForm();" class="btn btn-primary btn-sm form-control" href="#">Descargar</a>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- Fin Modal -->
<script src="assets/plugins/html2pdf.bundle.min.js"></script>
<script type="text/javascript">

function downForm(fecha1, fecha2) {
    fecha1 = $('#fecha1').val();
    fecha2 = $('#fecha2').val();
	if(fecha1 == ""||fecha2==""){
                  toastr.warning('las fechas no pueden estar vacias');
                }else{
	$.ajax({
		type: 'POST',
		url: 'reportes/pdf_necesidad.php',
		data: {fecha1:fecha1,fecha2:fecha2},
		success: function(data) {
			generatePDF(data);
		}
				})};
}

function generatePDF (element) {
	var opt = {
		margin:       0.5,
		filename:     'Necesidad de fortalecimiento de infraestructura.pdf',
		image:        { type: 'jpeg', quality: 0.98 },
		html2canvas:  { scale: 1 },
		jsPDF:        { unit: 'in', format: 'letter',  }
	};
	html2pdf()
	.set(opt)
	.from(element)
	.save();
}
</script>
<?php include('includes/footer.php'); ?>