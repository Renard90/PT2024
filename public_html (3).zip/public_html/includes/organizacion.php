<?php
  session_start();
  include('modulo/conexion.php');
  include('modulo/validar.php');

  $id = $_SESSION['xID'];
  $nombre = $_SESSION['xNombre'];
  $apellido = $_SESSION['xApellido'];
  $usuario = $nombre." ".$apellido;
?>
<?php include('includes/header.php'); ?>
<div class="d-flex" id="content-wrapper">
  <?php include('includes/sidebar.php'); ?>
  <!-- Page Content -->
  <div id="content" class="bg-grey">
    <section class="bg-light py-3">
      <div class="container">
        <div class="row">
          <div class="col-lg-9 col-md-8">
            <h1 class="font-weight-bold mb-0"> Organización de Actividades</h1>
          </div>
          <div class="col-lg-3 col-md-4 d-flex">
            <a data-toggle="modal" data-target="#view-modal" class="btn btn-primary align-self-center" href="#">Descargar reporte</a>
          </div>
        </div>
      </div>
    </section>
    <!-- Organización de Actividades -->
    <section>
      <div class="container">
        <div class="row">
          <!-- Margen anchura del cuadro FORM -->
          <div class="col-lg-8 my-3">
            <!-- Margen del cuadro FORM -->
            <div class="card rounded-0">
              <div class="card-header bg-light">
                <h6 class="font-weight-bold mb-0">Académicas y/o Científicas</h6>
              </div>
              <div class="card-body">
                <!-- Formulario -->
                <form id="insert" action="process/insert_organizacion.php" method="POST">
                <input type="hidden" value="<?php echo $usuario; ?>" name="usuario">
                  <div class="form-group">
                    <label for="inputAddress">Nombre de las Académicas Actividades y/o Científicas </label>
                    <input type="text" required name="nombre" class="form-control" id="inputAddress" placeholder="Nombre">
                  </div>
                  <div class="form-group">
                    <label for="inputAddress">Nombre del Proyecto</label>
                    <input type="text" required name="proyecto" class="form-control" id="inputAddress" placeholder="Proyecto">
                  </div>
                  <!-- Fecha -->
                  <label for="start">Fecha de Inicio:</label>
                  <input type="date" name="inicio" id="start"  >
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <!-- Fecha -->
                  <label for="start">Fecha de Fin:</label>
                  <input type="date" name="fin" id="start"  >
                  <!-- Institución -->
				  <div class="form-group">
                    <label for="inputAddress">Institución </label>
                    <input type="text" required name="institucion" class="form-control" id="inputAddress" placeholder="Institución">
                  </div>
                  <button type="submit" class="btn btn-primary">Done</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>
<!-- Inicio Modal -->
<div class="modal fade" id="view-modal">
	<div class="modal-dialog ">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Preparando Reporte...</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<div class="show-info modal-body">
				<form  action="" method="POST">
					<div class="card-body">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="name">Fecha inicial de búsqueda</label><br>
									<input  type="date"  id="fecha1" name="fecha1">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="name">Fecha final de búsqueda</label><br>
									<input  type="date"  id="fecha2" name="fecha2">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<a onclick="downForm();" class="btn btn-primary btn-sm form-control" href="#">Descargar</a>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- Fin Modal -->
<script src="assets/plugins/html2pdf.bundle.min.js"></script>
<script type="text/javascript">

function downForm(fecha1, fecha2) {
    fecha1 = $('#fecha1').val();
    fecha2 = $('#fecha2').val();
	if(fecha1 == ""||fecha2==""){
                  toastr.warning('las fechas no pueden estar vacias');
                }else{
	$.ajax({
		type: 'POST',
		url: 'reportes/pdf_organizacion.php',
		data: {fecha1:fecha1,fecha2:fecha2},
		success: function(data) {
			generatePDF(data);
		}
				})};
}

function generatePDF (element) {
	var opt = {
		margin:       0.5,
		filename:     'Organización de Actividades.pdf',
		image:        { type: 'jpeg', quality: 0.98 },
		html2canvas:  { scale: 1 },
		jsPDF:        { unit: 'in', format: 'letter',  }
	};
	html2pdf()
	.set(opt)
	.from(element)
	.save();
}
</script>
<?php include('includes/footer.php'); ?>