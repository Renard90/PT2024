<div id="sidebar-container" class="bg-primary">
      <div class="logo">
        <h4 class="text-light font-weight-bold mb-0"><a href="index.php">UACJ</a></h4>
      </div>
      <div class="menu">
        <!-- SECCION 0 -->
        <a href="index.php" class="d-block text-light p-2 border-0"><i class="icon ion-md-home lead mr-2"></i>
          Inicio</a>
        <!-- SECCION 1 -->
        <a href="evaluacion.php" class="d-block text-light p-2 border-0"><i class="icon ion-md-apps lead mr-2"></i>
          Índices de Evaluación e Impacto de la Calidad Investigadora</a>
		    <!-- SECCION 2 -->
        <a href="articulosjcr.php" class="d-block text-light p-2 border-0"><i class="icon ion-md-book lead mr-2"></i>
          Articulos indizados en JCR y otros Índices</a>
		<!-- SECCION 3 -->
        <a href="articulosdiv.php" class="d-block text-light p-2 border-0"><i class="icon ion-md-book lead mr-2"></i>
          Articulos de divulgación y Capítulos de libro</a>
		<!-- SECCION 4 -->
        <a href="publicaciones.php" class="d-block text-light p-2 border-0"><i class="icon ion-md-people lead mr-2"></i>
          Congresos Internacionales y Nacionales</a>
        <!-- SECCION 5 -->
        <a href="proyectos.php" class="d-block text-light p-2 border-0"><i class="icon ion-md-people lead mr-2"></i>
          Proyectos con/sin financiamiento</a>
        <!-- SECCION 6 -->
        <a href="estancias.php" class="d-block text-light p-2 border-0"><i class="icon ion-md-stats lead mr-2"></i>
          Estancias académicas</a>
        <!-- SECCION 7 -->
        <a href="formacion.php" class="d-block text-light p-2 border-0"><i class="icon ion-md-person lead mr-2"></i>
          Formación de Recursos Humanos</a>
        <!-- SECCION 8 -->
        <a href="organizacion.php" class="d-block text-light p-2 border-0"> <i
            class="icon ion-md-settings lead mr-2"></i>
          Organización de Actividades</a>
        <!-- SECCION 9 -->
        <a href="plan.php" class="d-block text-light p-2 border-0"> <i class="icon ion-md-settings lead mr-2"></i>
          Plan de Trabajo</a>
        <!-- SECCION 10 -->
        <a href="necesidad.php" class="d-block text-light p-2 border-0"> <i class="icon ion-md-settings lead mr-2"></i>
          Necesidad de fortalecimiento de infraestructura</a>
      </div>
	  </div>
	<!-- Fin sidebar -->

    <div class="w-100">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <div class="container">
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
              <li class="nav-item dropdown">
                <a class="nav-link text-dark dropdown-toggle" href="#" id="navbarDropdown" role="button"
                  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo $xNombre." ".$xApellido; ?>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="perfil.php">Mi perfil</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="cerrar-sesion.php">Cerrar sesión</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- Fin Navbar -->