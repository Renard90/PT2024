<?php
  session_start();
  include('modulo/conexion.php');
  include('modulo/validar.php');

  $id = $_SESSION['xID'];
  $nombre = $_SESSION['xNombre'];
  $apellido = $_SESSION['xApellido'];
  $usuario = $nombre." ".$apellido;
 
?>
<?php 	include('includes/header.php');
		
 ?>
<div class="d-flex" id="content-wrapper">
    <?php include('includes/sidebar.php'); ?>
    <!-- Page Content -->
    <div id="content" class="bg-grey w-100">
        <section class="bg-light py-3">
            <div class="container">
			<?php include('includes/tables/table_evaluacion.php'); ?>
                <div class="row">
                    <div class="col-lg-3 col-md-4 d-flex">
                        <a data-toggle="modal" data-target="#view-modal" class="btn btn-primary w-100 align-self-center" href="#">Descargar reporte</a>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<!-- Inicio Modal -->
<div class="modal fade" id="view-modal">
	<div class="modal-dialog ">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Preparando Reporte...</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<div class="show-info modal-body">
				<form  action="" method="POST">
					<div class="card-body">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="name">Fecha inicial de captura</label><br>
									<input required type="date" id="fecha1" name="fecha1">
								</div>
							</div>
						</div>
					
					
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="name">Fecha final de captura</label><br>
									<input required type="date"id="fecha2" name="fecha2">
								</div>
							</div>
						</div>
					
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<a onclick="downForm();" class="btn btn-primary btn-sm form-control" href="#">Descargar</a>
								</div>
							</div>
						</div>
					
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- Fin Modal -->
<script src="assets/plugins/html2pdf.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.10/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.10/vfs_fonts.js"></script>
<script type="text/javascript">

 function generatePDF (htmlContent) {
	return new Promise((resolve, reject) => {
        try {
            // Define document definition
            const documentDefinition = {
                content: [
                    {
                        // Convert HTML content to a stack element
                        stack: [
                            {
                                // Convert HTML string to pdfmake's "stack" format
                                text: htmlContent,
                                lineHeight: 1.5,
                            },
                        ],
                    },
                ],
            };

            // Create a PDF document
            const pdfDoc = pdfMake.createPdf(documentDefinition);

            // Generate PDF and return it as a blob
            pdfDoc.getBlob((blob) => {
                resolve(blob);
            }, (error) => {
                reject(error);
            });
        } catch (error) {
            reject(error);
        }
    });
}

function downForm(fecha1, fecha2) {
    fecha1 = $('#fecha1').val();
    fecha2 = $('#fecha2').val();
	if(fecha1 == ""||fecha2==""){
                  toastr.warning('las fechas no pueden estar vacias');
                }else{
	$.ajax({
		type: 'POST',
		url: 'reportes/pdf_evaluacion.php',
		data: {fecha1:fecha1,fecha2:fecha2},
		success: async function(data) {
			try {
        // Generate PDF from HTML content
        const pdfBlob = await generatePDF(data);

        // Example: Download PDF
        const blobUrl = URL.createObjectURL(pdfBlob);
        const link = document.createElement('a');
        link.href = blobUrl;
        link.download = 'output.pdf';
        link.click();
        URL.revokeObjectURL(blobUrl);
    } catch (error) {
        console.error('Error generating PDF:', error);
    };
		}
				})};
}



$( document ).ready(function() {
     $('#evaluacion').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true,
      "responsive": true
    })
    });
	DataTable('#evaluacion', {
    layout: {
        topStart: {
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
        }
    }
});



</script>
<?php include('includes/footer.php'); ?>