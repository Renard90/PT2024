<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Spartan:wght@300;600&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/ffec4ec2ed.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="assets/plugins/toastr/toastr.min.css">
    <script src="assets/plugins/jquery/jquery.min.js"></script>
    <script src="assets/plugins/jquery-ui/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="assets/css/style2.css" />
	

    <title>Crear Cuenta</title>
  </head>
  
  <body class="bg-dark">
      <section>
            <div class="col-lg-7 bg-dark d-flex  min-vh-100">
                <div class="align-self-center w-100 px-lg-5 py-lg-4 p-4">
                <h1 class="font-weight-bold mb-4">Bienvenido</h1>
                <form id="crear" action="process/insert_usuario.php" method="POST" class="mb-5">
                    <div class="mb-4">
                      <label for="exampleInputEmail1" class="form-label font-weight-bold">Nombre</label>
                      <input type="text" required name="nombre" class="form-control bg-dark-x border-0" id="exampleInputname" placeholder="Ingresa tu nombre" pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]*" title="Solo letras y espacios">
                    </div>
                    <div class="mb-4">
                      <label for="exampleInputEmail1" class="form-label font-weight-bold">Apellido</label>
                      <input type="text" required name="apellido" class="form-control bg-dark-x border-0" id="exampleInputlastname" placeholder="Ingresa tu apellido" pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]*" title="Solo letras y espacios">
                    </div>
                    <div class="mb-4">
                      <label for="exampleInputEmail1" class="form-label font-weight-bold">Email</label>
                      <input type="email" required name="correo" class="form-control bg-dark-x border-0" id="exampleInputEmail1" placeholder="Ingresa tu email">
                    </div>
                    <div class="mb-4">				
						<label for="exampleInputPassword" class="form-label font-weight-bold">Contraseña</label>
						<div class="input-group-append">
							<input type="password" name="password" required class="form-control bg-dark-x border-0 mb-2" placeholder="Ingresa tu contraseña" id="exampleInputPassword" pattern=".{6,20}" title="Ingrese de 6 a 20 caracteres"> 
							<label for="exampleInputPassword2" class="form-label font-weight-bold">Confirmar Contraseña</label>
						<div class="input-group-append">
							<input type="password" name="password2" required class="form-control bg-dark-x border-0 mb-2" placeholder="Ingresa tu contraseña" id="exampleInputPassword2" pattern=".{6,20}" title="Ingrese de 6 a 20 caracteres" > 
						</div>
							<button id="show_password" class="btn btn-primary" type="button" onclick="mostrarPassword()"> <span class="fa fa-eye-slash icon"></span> </button>
						</div>
					</div>
                    <button type="submit" class="btn btn-primary w-100">Crear Cuenta</button>
                  </form>
                <div class="text-center px-lg-5 pt-lg-3 pb-lg-4 p-4 mt-auto w-100">
                    <p class="d-inline-block mb-0">¿Ya tienes una cuenta?</p> <a href="login.php" class="text-light font-weight-bold text-decoration-none">Inicia sesión</a>
                </div>
            </div>
        </div>
      </section>
	  </body>
	  </html>
	  
      <script type="text/javascript">
		

        $("#crear").submit(function(e) {
        e.preventDefault();
        var form = $(this);
        var url = form.attr('action');
        var temp = form.serialize();
		toastr.options = {
        "positionClass": "toast-top-center",
        "timeOut": "3500",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
        }
        $.ajax({
            type: "POST",
            url: url,
            data: form.serialize(), 
            success: function(data)
            {
            console.log(data);
                if(data == 2){
                  toastr.warning('¡Este correo ya ha sido registrado anteriormente!');
                }else if (data == 3) {
					toastr.warning('¡Los password no coinciden!');
				}
                else if (data=="true") {
                toastr.success('Cuenta creada correctamente');
                $('#crear').trigger("reset");
                //location.reload(10000);
                }
                else {
                    console.log(data);
                    toastr.error('!Hubo un error¡ Intente de nuevo');
		$('#crear').trigger("reset");}}});});
					
function mostrarPassword(){
		var cambio = document.getElementById("exampleInputPassword");
		if(cambio.type == "password"){
			cambio.type = "text";
			$('.icon').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
		}else{
			cambio.type = "password";
			$('.icon').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
		}
		var cambio = document.getElementById("exampleInputPassword2");
		if(cambio.type == "password"){
			cambio.type = "text";
		}else{
			cambio.type = "password";
		}
	} 
	
	$(document).ready(function () {
	//CheckBox mostrar contraseña
	$('#ShowPassword').click(function () {
		$('#Password').attr('type', $(this).is(':checked') ? 'text' : 'password');
	});
});
</script>
    <!-- Optional JavaScript -->
    <!-- Popper.js first, then Bootstrap JS -->
    <script src="assets/plugins/toastr/toastr.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>
  

