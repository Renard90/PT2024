<!-- Inicio Tabla -->
<section id="myDIV" class="content">
        <div id="myDIV2" class="card">
            <div class="card-header"></div>
            <div id="myDIV1" class="card-body p-0">
              <h4 style="color:black; margin:0 auto;" >Formación de Recursos Humanos - Servicio Social</h4>
                <table id="social" class="table table-bordered table-hover projects">
                    <thead>
                        <tr>
                            <th>
                                Nombre del Alumno 
                            </th>
                            <th>
                                Nombre del Proyecto 
                            </th>
                            <th>
                                Programa 
                            </th>
                            <th>
                                Fecha de Inicio
                            </th>
                            <th>
                                Fecha de Fin 
                            </th>
                            <th>
                                Fecha 
                            </th>
                            <th>
                                Opciones
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                      $QuerySocial = "SELECT * FROM tbl_servicio_actividad WHERE tipo = 'Servicio Social';";
                      $ResultSocial = mysqli_query($conexion, $QuerySocial);
                      while($RowSocial = mysqli_fetch_array($ResultSocial)){
                        $id_social = $RowSocial['id_servicio'];
                        $nombre = utf8_decode($RowSocial['nombre']);
                        $proyecto = utf8_decode($RowSocial['proyecto']);
                        $programa = utf8_decode($RowSocial['programa']);
                        $inicio = $RowSocial['inicio'];
                        $fin = $RowSocial['fin'];
                        $fecha = $RowSocial['fecha'];

                        if($programa == "Sotfware"){
                            $programa2 = "Ingeniería de Sotfware";
                        }elseif($programa == "Sistemas Computacionales"){
                            $programa2 = "Ingeniería en Sistemas Computacionales";
                        }
                    ?> 
                        <tr >
                            <td>
                              <?php echo $nombre; ?>
                            </td>
                            <td>
                              <?php echo $proyecto; ?>
                            </td>
                            <td>
                              <?php echo $programa2; ?>
                            </td>
                            <td>
                              <?php echo $inicio; ?>
                            </td>
                            <td>
                              <?php echo $fin; ?>
                            </td>
                            <td>
                              <?php echo $fecha; ?>
                            </td>
                            <td>
                                <a data-toggle="modal" data-target="#edit<?php echo $id_social; ?>"  class="btn btn-info btn-sm" href="#">
                                    Editar
                                </a>
                                <a data-toggle="modal" data-target="#delete<?php echo $id_social; ?>"  class="btn btn-danger btn-sm" href="#">
                                    Eliminar
                                </a>
                            </td>
                        </tr>
                        <!-- Inicio Borrar -->
                        <div class="modal fade" id="delete<?php echo $id_social; ?>">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content bg-danger text-light">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Borrar Registro</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>
                                    <div class="modal-body text-center">
                                        <form id="borrar-registro" action="process/delete_social.php" method="POST">
                                            <h2>Esta acción no puede revertirse</h2>
                                            <input type="hidden" name="id_social" value="<?php echo $id_social; ?>">
                                            <button type="submit" class="btn btn-light mt-2 btn-block">Borrar!</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Fin Borrar -->
                        <!-- Inicio Editar -->
                        <div class="modal fade" id="edit<?php echo $id_social ?>">
                            <div class="modal-dialog modal-xl">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Editando</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form id="actualizar<?php echo $fecha; ?>" method="POST" action="process/edit_social.php">
                                            <input type="hidden" required class="form-control" name="id_social" value="<?php echo $id_social ?>" hidden>
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="nombre">Nombre del Alumno</label>
                                                            <input name="nombre" id="nombre" class="form-control" value="<?php echo $nombre ?>" >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="proyecto">Nombre del Proyecto</label>
                                                            <input name="proyecto" id="proyecto" class="form-control" value="<?php echo $proyecto ?>" >
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="programa">Programa</label>
                                                            <select name="programa" id="programa" class="form-control">
                                                                <?php if($programa2 == "Ingeniería de Sotfware"){?>
                                                                    <option selected value="Sotfware">Ingeniería de Sotfware</option>
                                                                    <option value="Sistemas Computacionales">Ingeniería en Sistemas Computacionales</option>
                                                                <?php } ?>
                                                                <?php if($programa2 == "Ingeniería en Sistemas Computacionales"){?>
                                                                    <option value="Sotfware">Ingeniería de Sotfware</option>
                                                                    <option selected value="Sistemas Computacionales">Ingeniería en Sistemas Computacionales</option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="proyecto">Fecha de Inicio</label>
                                                            <input type="date"  class="form-control" id="inicio" name="inicio" value="<?php echo $inicio; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="autores">Fecha de Fin</label>
                                                            <input type="date"  class="form-control" id="fin" name="fin" value="<?php echo $fin; ?>">
                                                        </div>
                                                    </div>
                                                <div class="row">
                                                    <button type="submit" class="btn btn-primary">Editar</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="modal-footer justify-content-between">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Fin Editar -->
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
    <!-- Fin Tabla -->