<!-- Inicio Tabla -->
<section id="myDIV" class="content">
        <div id="myDIV2" class="card">
            <div class="card-header"></div>
            <div id="myDIV1" class="card-body p-0">
              <h4 style="color:black; margin:0 auto;" >Formación de Recursos Humanos - Becarios</h4>
                <table id="becarios" class="table table-bordered table-hover projects">
                    <thead>
                        <tr>
                            <th>
                                Nombre del Alumno 
                            </th>
                            <th>
                                Nombre del Proyecto 
                            </th>
                            <th>
                                Fecha de Inicio
                            </th>
                            <th>
                                Fecha de Fin 
                            </th>
                            <th>
                                Fecha 
                            </th>
                            <th>
                                Opciones
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                      $QueryBecarios = "SELECT * FROM tbl_becarios;";
                      $ResultBecarios = mysqli_query($conexion, $QueryBecarios);
                      while($RowBecarios = mysqli_fetch_array($ResultBecarios)){
                        $id_becarios = $RowBecarios['id_becarios'];
                        $nombre = utf8_decode($RowBecarios['nombre']);
                        $proyecto = utf8_decode($RowBecarios['proyecto']);
                        $inicio = utf8_decode($RowBecarios['inicio']);
                        $fin = utf8_decode($RowBecarios['fin']);
                        $fecha = $RowBecarios['fecha'];
                    ?> 
                        <tr>
                            <td>
                              <?php echo $nombre; ?>
                            </td>
                            <td>
                              <?php echo $proyecto; ?>
                            </td>
                            <td>
                              <?php echo $inicio; ?>
                            </td>
                            <td>
                              <?php echo $fin; ?>
                            </td>
                            <td>
                              <?php echo $fecha; ?>
                            </td>
                            <td>
                                <a data-toggle="modal" data-target="#edit<?php echo $id_becarios; ?>"  class="btn btn-info btn-sm" href="#">
                                    Editar
                                </a>
                                <a data-toggle="modal" data-target="#delete<?php echo $id_becarios; ?>"  class="btn btn-danger btn-sm" href="#">
                                    Eliminar
                                </a>
                            </td>
                        </tr>
                        <!-- Inicio Borrar -->
                        <div class="modal fade" id="delete<?php echo $id_becarios; ?>">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content bg-danger text-light">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Borrar Registro</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>
                                    <div class="modal-body text-center">
                                        <form id="borrar-registro" action="process/delete_becarios.php" method="POST">
                                            <h2>Esta acción no puede revertirse</h2>
                                            <input type="hidden" name="id_becarios" value="<?php echo $id_becarios; ?>">
                                            <button type="submit" class="btn btn-light mt-2 btn-block">Borrar!</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Fin Borrar -->
                        <!-- Inicio Editar -->
                        <div class="modal fade" id="edit<?php echo $id_becarios ?>">
                            <div class="modal-dialog modal-xl">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Editando</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form id="actualizar<?php echo $fecha; ?>" method="POST" action="process/edit_becarios.php">
                                            <input type="hidden" required class="form-control" name="id_becarios" value="<?php echo $id_becarios ?>" hidden>
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="nombre">Nombre del Alumno</label>
                                                            <input name="nombre" id="nombre" class="form-control" value="<?php echo $nombre ?>" >
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="nombre">Nombre del Proyecto</label>
                                                            <input name="proyecto" id="proyecto" class="form-control" value="<?php echo $proyecto ?>" >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="proyecto">Fecha de Inicio</label>
                                                            <input type="date"  class="form-control" id="inicio" name="inicio" value="<?php echo $inicio; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="autores">Fecha de Fin</label>
                                                            <input type="date"  class="form-control" id="fin" name="fin" value="<?php echo $fin; ?>">
                                                        </div>
                                                    </div>
                                                <div class="row">
                                                    <button type="submit" class="btn btn-primary">Editar</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="modal-footer justify-content-between">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Fin Editar -->
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
    <!-- Fin Tabla -->