<!-- Inicio Tabla -->
<section id="myDIV" class="content">
        <div id="myDIV2" class="card">
            <div class="card-header"></div>
            <div id="myDIV1" class="card-body p-0">
              <h4 style="color:black; margin:0 auto;" >Estancias Académicas</h4>
                <table id="estancias" class="table table-bordered table-hover projects ">
                    <thead>
                        <tr>
                            <th>
                                Nombre
                            </th>
                            <th>
                                Estancia realizada
                            </th>
                            <th>
                                Autores
                            </th>
                            <th>
                                Institucion
                            </th>
                            <th>
                                Estancias
                            </th>
                            <th>
                                Fecha
                            </th>
                            <th style="nowrap; overflow-x: auto;">
                                Opciones
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                      $QueryEstancias = "SELECT * FROM tbl_estancias;";
                      $ResultEstancias = mysqli_query($conexion, $QueryEstancias);
                      while($RowEstancias = mysqli_fetch_array($ResultEstancias)){
                        $id_estancias = $RowEstancias['id_estancias'];
                        $nombre = utf8_decode($RowEstancias['nombre']);
                        $proyecto = utf8_decode($RowEstancias['proyecto']);
                        $autores = utf8_decode($RowEstancias['autores']);
                        $institucion = utf8_decode($RowEstancias['institucion']);
                        $estancias = utf8_decode($RowEstancias['estancias']);
                        $fecha = $RowEstancias['fecha'];
                    ?> 
                        <tr >
                            <td>
                              <?php echo $nombre; ?>
                            </td>
                            <td>
                              <?php echo $proyecto; ?>
                            </td>
                            <td>
                              <?php echo $autores; ?>
                            </td>
                            <td>
                              <?php echo $institucion; ?>
                            </td>
                            <td>
                              <?php echo $estancias; ?>
                            </td>
                            <td>
                              <?php echo $fecha; ?>
                            </td>
                            <td style="nowrap; overflow-x: auto;">
                                <a data-toggle="modal" data-target="#edit<?php echo $id_estancias; ?>"  class="btn btn-info btn-sm" href="#">
                                    Editar
                                </a>
                                <a data-toggle="modal" data-target="#delete<?php echo $id_estancias; ?>"  class="btn btn-danger btn-sm " style="nowrap; overflow-x: auto;" href="#">
                                    Eliminar
                                </a>
                            </td>
                        </tr>
                        <!-- Inicio Borrar -->
                        <div class="modal fade" id="delete<?php echo $id_estancias; ?>">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content bg-danger text-light">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Borrar Registro</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>
                                    <div class="modal-body text-center">
                                        <form id="borrar-registro" action="process/delete_estancias.php" method="POST">
                                            <h2>Esta acción no puede revertirse</h2>
                                            <input type="hidden" name="id_estancias" value="<?php echo $id_estancias; ?>">
                                            <button type="submit" class="btn btn-light mt-2 btn-block">Borrar!</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Fin Borrar -->
                        <!-- Inicio Editar -->
                        <div class="modal fade" id="edit<?php echo $id_estancias; ?>">
                            <div class="modal-dialog modal-xl">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Editando</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form id="actualizar<?php echo $fecha; ?>" method="POST" action="process/edit_estancias.php">
                                            <input type="hidden" required class="form-control" name="id_estancias" value="<?php echo $id_estancias; ?>" hidden>
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="nombre">Nombre de la Estancia</label>
                                                            <input type="text"  class="form-control" id="nombre" name="nombre" value="<?php echo $nombre; ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="proyecto">Nombre del Proyecto</label>
                                                            <input type="text"  class="form-control" id="proyecto" name="proyecto" value="<?php echo $proyecto; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="autores">Autores</label>
                                                            <input type="text"  class="form-control" id="autores" name="autores" value="<?php echo $autores; ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="form-group">
														<label for="institucion">Institución </label>
														<input type="text" required name="institucion" class="form-control" id="inputAddress" value="<?php echo $institucion; ?>">
													</div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="autores">Estancias</label>
                                                            <select  name="estancias" class="form-control">
                                                                <?php if ($estancias == "Nacionales"){?>
                                                                    <option selected value="Nacionales">Nacionales</option>
                                                                    <option value="Internacionales">Internacionales</option>
                                                                <?php } ?>
                                                                <?php if ($estancias == "Internacionales"){?>
                                                                    <option value="Nacionales">Nacionales</option>
                                                                    <option selected value="Internacionales">Internacionales</option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <button type="submit"  class="btn btn-primary">Editar</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="modal-footer justify-content-between">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Fin Editar -->
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
    <!-- Fin Tabla -->