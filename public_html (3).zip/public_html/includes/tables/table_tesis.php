<!-- Inicio Tabla -->
<section id="myDIV" class="content">
        <div id="myDIV2" class="card">
            <div class="card-header"></div>
            <div id="myDIV1" class="card-body p-0">
              <h4 style="color:black; margin:0 auto;" >Formación de Recursos Humanos - Tesis</h4>
                <table id="tesis" class="table table-bordered table-hover projects">
                    <thead>
                        <tr>
                            <th>
                                Tipo
                            </th>
                            <th>
                                Nombre
                            </th>
                            <th>
                                Autor
                            </th>
                            <th>
                                Fecha de Tesis
                            </th>
                            <th>
                                Institucion
                            </th>
                            <th>
                                Programa
                            </th>
                            <th>
                                Estado
                            </th>
                            <th>
                                Fecha
                            </th>
                            <th>
                                Opciones
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                      $QueryTesis = "SELECT * FROM tbl_tesis;";
                      $ResultTesis = mysqli_query($conexion, $QueryTesis);
                      while($RowTesis = mysqli_fetch_array($ResultTesis)){
                        $id_tesis = $RowTesis['id_tesis'];
                        $tipo = utf8_decode($RowTesis['tipo']);
                        $nombre = utf8_decode($RowTesis['nombre']);
                        $autor = utf8_decode($RowTesis['autor']);
                        $fecha_tesis = utf8_decode($RowTesis['fecha_tesis']);
                        $institucion = utf8_decode($RowTesis['institucion']);
                        $programa = utf8_decode($RowTesis['programa']);
                        $estado = utf8_decode($RowTesis['estado']);
                        $fecha = $RowTesis['fecha'];
                    ?> 
                        <tr> 
                            <td>
                              <?php echo $tipo; ?>
                            </td>
                            <td>
                              <?php echo $nombre; ?>
                            </td>
                            <td>
                              <?php echo $autor; ?>
                            </td>
                            <td>
                              <?php echo $fecha_tesis; ?>
                            </td>
                            <td>
                              <?php echo $institucion; ?>
                            </td>
                            <td>
                              <?php echo $programa; ?>
                            </td>
                            <td>
                              <?php echo $estado; ?>
                            </td>
                            <td>
                              <?php echo $fecha; ?>
                            </td>
                            <td>
                                <a data-toggle="modal" data-target="#edit<?php echo $id_tesis; ?>"  class="btn btn-info btn-sm" href="#">
                                    Editar
                                </a>
                                <a data-toggle="modal" data-target="#delete<?php echo $id_tesis; ?>"  class="btn btn-danger btn-sm" href="#">
                                    Eliminar
                                </a>
                            </td>
                        </tr>
                        <!-- Inicio Borrar -->
                        <div class="modal fade" id="delete<?php echo $id_tesis; ?>">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content bg-danger text-light">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Borrar Registro</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>
                                    <div class="modal-body text-center">
                                        <form id="borrar-registro" action="process/delete_tesis.php" method="POST">
                                            <h2>Esta acción no puede revertirse</h2>
                                            <input type="hidden" name="id_tesis" value="<?php echo $id_tesis; ?>">
                                            <button type="submit" class="btn btn-light mt-2 btn-block">Borrar!</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Fin Borrar -->
                        <!-- Inicio Editar -->
                        <div class="modal fade" id="edit<?php echo $id_tesis; ?>">
                            <div class="modal-dialog modal-xl">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Editando</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form id="actualizar<?php echo $fecha; ?>" method="POST" action="process/edit_tesis.php">
                                            <input type="hidden" required class="form-control" name="id_tesis" value="<?php echo $id_tesis; ?>" hidden>
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="nombre">Nombre de la Tesis</label>
                                                            <input type="text"  class="form-control" id="nombre" name="nombre" value="<?php echo $nombre; ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="autor">Nombre del Autor</label>
                                                            <input type="text"  class="form-control" id="autor" name="autor" value="<?php echo $autor; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="fecha_tesis">Fecha</label>
                                                            <input type="date"  class="form-control" id="fecha_tesis" name="fecha_tesis" value="<?php echo $fecha_tesis; ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label for="proyecto">Institución</label>
                                                            <select  name="institucion" class="form-control">
                                                                <?php if ($institucion == "UACJ-DMCU"){?>
                                                                    <option selected value="UACJ-DMCU">UACJ-DMCU</option>
                                                                    <option value="UACJ-IIT">UACJ-IIT</option>
                                                                <?php } ?>
                                                                <?php if ($institucion == "UACJ-IIT"){?>
                                                                    <option value="UACJ-DMCU">UACJ-DMCU</option>
                                                                    <option selected value="UACJ-IIT">UACJ-IIT</option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label for="programa">Programa</label>
                                                            <select  name="programa" class="form-control">
                                                                <?php if ($tipo == "Licenciatura"){?>
                                                                    <?php if ($programa == "Sotfware"){?>
                                                                        <option selected value="Sotfware">Ingeniería de Sotfware</option>
                                                                        <option value="Sistemas Computacionales">Ingeniería en Sistemas Computacionales</option>
                                                                    <?php } ?>
                                                                    <?php if ($programa == "Sistemas Computacionales"){?>
                                                                        <option value="Sotfware">Ingeniería de Sotfware</option>
                                                                        <option selected value="Sistemas Computacionales">Sistemas Computacionales</option>
                                                                    <?php } ?>
                                                                <?php }?>
                                                                <?php if ($tipo == "Maestria"){?>
                                                                    <?php if ($programa == "Cómputo aplicado"){?>
                                                                        <option selected value="Cómputo aplicado">Cómputo aplicado</option>
                                                                        <option value="Ciencias de la Computación">Ciencias de la Computación</option>
                                                                        <option value="Ingeniería industrial">Ingeniería industrial</option>
                                                                        <option value="En Tecnología">En Tecnología</option>
                                                                    <?php } ?>
                                                                    <?php if ($programa == "Ciencias de la Computación"){?>
                                                                        <option value="Cómputo aplicado">Cómputo aplicado</option>
                                                                        <option selected value="Ciencias de la Computación">Ciencias de la Computación</option>
                                                                        <option value="Ingeniería industrial">Ingeniería industrial</option>
                                                                        <option value="En Tecnología">En Tecnología</option>
                                                                    <?php } ?>
                                                                    <?php if ($programa == "Ingeniería industrial"){?>
                                                                        <option value="Cómputo aplicado">Cómputo aplicado</option>
                                                                        <option value="Ciencias de la Computación">Ciencias de la Computación</option>
                                                                        <option selected value="Ingeniería industrial">Ingeniería industrial</option>
                                                                        <option value="En Tecnología">En Tecnología</option>
                                                                    <?php } ?>
                                                                    <?php if ($programa == "En Tecnología"){?>
                                                                        <option value="Cómputo aplicado">Cómputo aplicado</option>
                                                                        <option value="Ciencias de la Computación">Ciencias de la Computación</option>
                                                                        <option value="Ingeniería industrial">Ingeniería industrial</option>
                                                                        <option selected value="En Tecnología">En Tecnología</option>
                                                                    <?php } ?>
                                                                <?php }?>
                                                                <?php if ($tipo == "Doctorado"){?>
                                                                    <?php if ($programa == "Ciencias de la Ingeniería avanzada"){?>
                                                                        <option selected value="Ciencias de la Ingeniería avanzada">Ciencias de la Ingeniería avanzada</option>
                                                                        <option value="En Tecnología">En Tecnología</option>
                                                                        <option value="Ciencias de los materiales">Ciencias de los materiales</option>
                                                                    <?php } ?>
                                                                    <?php if ($programa == "En Tecnología"){?>
                                                                        <option value="Ciencias de la Ingeniería avanzada">Ciencias de la Ingeniería avanzada</option>
                                                                        <option selected value="En Tecnología">En Tecnología</option>
                                                                        <option value="Ciencias de los materiales">Ciencias de los materiales</option>
                                                                    <?php } ?>
                                                                    <?php if ($programa == "Ciencias de los materiales"){?>
                                                                        <option value="Ciencias de la Ingeniería avanzada">Ciencias de la Ingeniería avanzada</option>
                                                                        <option value="En Tecnología">En Tecnología</option>
                                                                        <option value="Ciencias de los materiales">Ciencias de los materiales</option>
                                                                    <?php } ?>
                                                                <?php }?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label for="estado">Tesis concluida o en proceso</label>
                                                            <select  name="estado" class="form-control">
                                                                <?php if ($estado == "Concluida"){?>
                                                                    <option selected value="Concluida">Concluida</option>
                                                                    <option value="Proceso">Proceso</option>
                                                                <?php } ?>
                                                                <?php if ($estado == "Proceso"){?>
                                                                    <option value="Concluida">Concluida</option>
                                                                    <option selected value="Proceso">Proceso</option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <button type="submit"  class="btn btn-primary">Editar</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="modal-footer justify-content-between">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Fin Editar -->
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
    <!-- Fin Tabla -->