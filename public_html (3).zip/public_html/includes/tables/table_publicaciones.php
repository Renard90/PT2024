<!-- Inicio Tabla -->
<section id="myDIV" class="content">
        <div id="myDIV2" class="card">
            <div class="card-header"></div>
            <div id="myDIV1" class="card-body p-0">
              <h4 style="color:black; margin:0 auto;" >Publicaciones</h4>
                <table id="publicaciones" class="table table-bordered table-hover projects">
                    <thead>
                        <tr>
                            <th>
                                Tipo de Publicaci&oacute;n 
                            </th>
                            <th>
                                Nombre del art&iacute;culo 
                            </th>
                            <th>
                                Autores
                            </th>
                            <th>
                                Página(s)
                            </th>
                            <th>
                                Fecha de publicaci&oacute;n
                            </th>
                            <th>
                                Revista/Libro
                            </th>
                            <th>
                                Link
                            </th>
                            <th>
                                Opciones
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                      $Querypubli = "SELECT * FROM tbl_publicaciones;";
                      $Resultpubli = mysqli_query($conexion, $Querypubli);
                      while($Rowpubli = mysqli_fetch_array($Resultpubli)){
                        $id_publicaciones = $Rowpubli['id_publicaciones'];
                        $tipo = utf8_decode($Rowpubli['tipo']);
                        $nombre = utf8_decode($Rowpubli['nombre']);
                        $autores = utf8_decode($Rowpubli['autores']);
                        $paginas = $Rowpubli['paginas'];
                        $publicacion = $Rowpubli['publicacion'];
                        $lugar = utf8_decode($Rowpubli['lugar']);
                        $link = base64_decode($Rowpubli['link']);
                        $fecha = $Rowpubli['fecha'];
                        
                        if($tipo == 'capitulos libro'){
                            $tipo2 = 'Capítulos de Libro';
                        }elseif($tipo == 'congresos'){
                            $tipo2 = 'Congresos Internacionales y Nacionales';
                        }elseif($tipo == 'articulos divulgacion'){
                            $tipo2 = 'Artículos de divulgación';
                        }elseif($tipo == 'otros indices'){
                            $tipo2 = 'Artículos en Otros Índices';
                        }
                        
                    ?> 
                        <tr>
                            <td>
                              <?php echo $tipo2; ?>
                            </td>
                            <td>
                              <?php echo $nombre; ?>
                            </td>
                            <td>
                              <?php echo $autores; ?>
                            </td>
                            <td>
                              <?php echo $paginas; ?>
                            </td>
                            <td>
                              <?php echo $publicacion; ?>
                            </td>
                            <td>
                              <?php echo $lugar; ?>
                            </td>
                            <td>
                              <?php echo $link; ?>
                            </td>
                            <td>
                                <a data-toggle="modal" data-target="#edit<?php echo $id_publicaciones; ?>"  class="btn btn-info btn-sm" href="#">
                                    Editar
                                </a>
                                <a data-toggle="modal" data-target="#delete<?php echo $id_publicaciones; ?>"  class="btn btn-danger btn-sm" href="#">
                                    Eliminar
                                </a>
                            </td>
                        </tr>
                        <!-- Inicio Borrar -->
                        <div class="modal fade" id="delete<?php echo $id_publicaciones; ?>">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content bg-danger text-light">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Borrar Registro</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>
                                    <div class="modal-body text-center">
                                        <form id="borrar-registro" action="process/delete_publicaciones.php" method="POST">
                                            <h2>Esta acción no puede revertirse</h2>
                                            <input type="hidden" name="id_publicaciones" value="<?php echo $id_publicaciones; ?>">
                                            <button type="submit" class="btn btn-light mt-2 btn-block">Borrar!</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Fin Borrar -->
                        <!-- Inicio Editar -->
                        <div class="modal fade" id="edit<?php echo $id_publicaciones; ?>">
                            <div class="modal-dialog modal-xl">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Editando</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form id="actualizar<?php echo $nombre; ?>" method="POST" action="process/edit_publicaciones.php">
                                            <input type="hidden" class="form-control" name="id_publicaciones" value="<?php echo $id_publicaciones; ?>" hidden>
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="nombre">Nombre del Articulo</label>
                                                            <input type="text"  class="form-control" id="nombre" name="nombre" value="<?php echo $nombre; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="autores">Autores</label>
                                                            <input type="text"  class="form-control" id="autores" name="autores" value="<?php echo $autores; ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="paginas">Páginas</label>
                                                            <input type="text"  class="form-control" id="paginas" name="paginas" value="<?php echo $paginas; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="publicacion">Fecha de Publicación</label>
                                                            <input type="date"  class="form-control" id="publicacion" name="publicacion" value="<?php echo $publicacion; ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="lugar">En</label>
                                                            <input type="text"  class="form-control" id="lugar" name="lugar" value="<?php echo $lugar; ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="link">Link</label>
                                                            <input type="text"  class="form-control" id="link" name="link" value="<?php echo $link; ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="tipo">Tipo de Publicación</label>
                                                            <select name="tipo" class="form-control">
                                                                <?php if ($tipo2 == "Capítulos de Libro"){?>
                                                                    <option selected value="capitulos libro">Capítulos de Libro</option>
                                                                    <option value="congresos">Congresos Internacionales y Nacionales</option>
                                                                    <option value="articulos divulgacion">Artículos de divulgación</option>
                                                                    <option value="otros indices">Artículos en Otros Índices</option>
                                                                <?php } ?>
                                                                <?php if ($tipo2 == "Congresos Internacionales y Nacionales"){?>
                                                                    <option value="capitulos libro">Capítulos de Libro</option>
                                                                    <option selected value="congresos">Congresos Internacionales y Nacionales</option>
                                                                    <option value="articulos divulgacion">Artículos de divulgación</option>
                                                                    <option value="otros indices">Artículos en Otros Índices</option>
                                                                <?php } ?>
                                                                <?php if ($tipo2 == "Artículos de divulgación"){?>
                                                                    <option value="capitulos libro">Capítulos de Libro</option>
                                                                    <option value="congresos">Congresos Internacionales y Nacionales</option>
                                                                    <option selected value="articulos divulgacion">Artículos de divulgación</option>
                                                                    <option value="otros indices">Artículos en Otros Índices</option>
                                                                <?php } ?>
                                                                <?php if ($tipo2 == "Artículos en Otros Índices"){?>
                                                                    <option value="capitulos libro">Capítulos de Libro</option>
                                                                    <option value="congresos">Congresos Internacionales y Nacionales</option>
                                                                    <option value="articulos divulgacion">Artículos de divulgación</option>
                                                                    <option selected value="otros indices">Artículos en Otros Índices</option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <button type="submit"  class="btn btn-primary">Editar</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="modal-footer justify-content-between">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Fin Editar -->
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
    <!-- Fin Tabla -->