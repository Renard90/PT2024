<?php
  session_start();
  include('modulo/conexion.php');
  include('modulo/validar.php');

  $id = $_SESSION['xID'];
  $nombre = $_SESSION['xNombre'];
  $apellido = $_SESSION['xApellido'];
  $usuario = $nombre." ".$apellido;
?>
<?php include('includes/header.php'); ?>
<div class="d-flex" id="content-wrapper">

  <?php include('includes/sidebar.php'); ?>

  <!-- Page Content -->
  <div id="content" class="bg-grey">

    <section class="bg-light py-3">
      <div class="container">
        <div class="row">
          <div class="col-lg-9 col-md-8">
            <h1 class="font-weight-bold mb-0">Publicaciones</h1>
          </div>
          <div class="col-lg-3 col-md-4 d-flex">
            <a data-toggle="modal" data-target="#view-modal" class="btn btn-primary w-100 align-self-center" href="#">Descargar reporte</a>
          </div>
        </div>
      </div>
    </section>

    <section class="bg-mix py-3">

    </section>
    <section>
      <!-- Congresos Internacionales y Nacionales-->
    <section>
      <div class="container">
        <div class="row">
          <!-- Margen anchura del cuadro FORM -->
          <div class="col-lg-10 my-3">
            <!-- Margen del cuadro FORM -->
            <div class="card rounded-0">
              <div class="card-header bg-light">
                <h6 class="font-weight-bold mb-0">Congresos Internacionales y Nacionales</h6>
              </div>
              <div class="card-body">
                <!-- Formulario -->
                <form id="insert4" action="process/insert_publicacion.php" method="POST">
                <input type="hidden" value="<?php echo $usuario; ?>" name="usuario">
                <input type="hidden" name="tipo" value="congresos">

                  <div class="form-group">
                    <label for="inputAddress">Título del trabajo presentado</label>
                    <input type="text" required name="nombre" id="nombre" class="form-control"  placeholder="Título">
                  </div>
                  <div class="form-row">
                    <div class="form-group col-md-6">
                      <label for="inputEmail4">Autores</label>
                      <input type="text" required name="autores" id="autores" class="form-control"  placeholder="Nombre de los autores">
                    </div>
                    <div class="form-group col-md-6">
                      <label for="inputPassword4">Página(s)</label>
                      <input type="text" required name="paginas" id="paginas" class="form-control"  placeholder="página(s)">
                    </div>
                  </div>
                   <div class="form-row">
                    <div class="form-group col-md-6">
                      <label for="inputEmail4">Editorial</label>
                      <input type="text" required name="doi" id="doi" class="form-control"  placeholder="Ed">
                    </div>
                
                    <div class="form-group col-md-6">
                      <label for="inputEmail4">ISBN</label>
                      <input type="text" required name="issn" id="issn" class="form-control"  placeholder="ISBN">
                    </div>
                    </div>

                  <!-- Fecha -->
                  <label for="start">Fecha de publicación:</label>
                  <input type="date" name="publicacion" id="publicacion"  min="2018-01-01" max="2024-12-31">

                  <div class="form-group">
                    <label for="inputAddress2">Nombre del congreso</label>
                    <input type="text" required name="lugar" id="lugar" class="form-control"  placeholder="Nombre">
                  </div>

                  <button type="submit" class="btn btn-primary">Done</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <div style="padding:1rem;"></div>
  </div>
</div>
<!-- Inicio Modal -->
<div class="modal fade" id="view-modal">
	<div class="modal-dialog ">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Preparando Reporte...</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<div class="show-info modal-body">
				<form  action="" method="POST">
					<div class="card-body">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="name">Fecha inicial de búsqueda</label><br>
									<input required type="date" id="fecha1" name="fecha1">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="name">Fecha final de búsqueda</label><br>
									<input required type="date"id="fecha2" name="fecha2">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<a onclick="downForm();" class="btn btn-primary btn-sm form-control" href="#">Descargar</a>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- Fin Modal -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.0.272/jspdf.debug.js"></"></script>
<script type="text/javascript" >

function downForm(fecha1, fecha2) {
    fecha1 = $('#fecha1').val();
    fecha2 = $('#fecha2').val();
	if(fecha1 == ""||fecha2==""){
                  toastr.warning('las fechas no pueden estar vacias');
                }else{
	$.ajax({
		type: 'POST',
		url: 'reportes/pdf_publicaciones.php',
		data: {fecha1:fecha1,fecha2:fecha2},
		success: function(data) {
			generatePDF(data);
		}
				})};
}


function generatePDF (element) {
	 var pdf = new jsPDF({
                     orientation: 'p',
                     unit: 'mm',
                     format: 'a5',
                     putOnlyUsedFonts:true
                     });
				 pdf.text(element, 20, 20);
                 pdf.addPage();
                 pdf.save('jsPDF_2Pages.pdf');
             }
}
</script>
<?php include('includes/footer.php'); ?>