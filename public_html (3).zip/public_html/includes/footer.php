<script>
$("#insert").submit(function(e) {
e.preventDefault();
var form = $(this);
var url = form.attr('action');
var temp = form.serialize();
toastr.options = {
  "positionClass": "toast-top-center",
  "timeOut": "1500",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut"
}
$.ajax({
     type: "POST",
     url: url,
     data: form.serialize(), 
     success: function(data)
     {
      console.log(data);
         if (data=="true") {
          toastr.success('Registro realizado correctamente ');
          $('#insert').trigger("reset");
          //location.reload(10000);
         }
         if (data!="true") {
            console.log(data);
            toastr.error('¡Hubo un error!  Intente de nuevo');
            $('#insert').trigger("reset");}}});});

$("#insert2").submit(function(e) {
e.preventDefault();
var form = $(this);
var url = form.attr('action');
var temp = form.serialize();
toastr.options = {
  "positionClass": "toast-top-center",
  "timeOut": "1500",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut"
}
$.ajax({
     type: "POST",
     url: url,
     data: form.serialize(), 
     success: function(data)
     {
      console.log(data);
         if (data=="true") {
          toastr.success('Registro realizado correctamente');
          $('#insert2').trigger("reset");
         }
         if (data!="true") {
            console.log(data);
            toastr.error('¡Hubo un error! Intente de nuevo');
            $('#insert2').trigger("reset");}}});});
            
$("#insert3").submit(function(e) {
e.preventDefault();
var form = $(this);
var url = form.attr('action');
var temp = form.serialize();
toastr.options = {
  "positionClass": "toast-top-center",
  "timeOut": "1500",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut"
}
$.ajax({
     type: "POST",
     url: url,
     data: form.serialize(), 
     success: function(data)
     {
      console.log(data);
         if (data=="true") {
          toastr.success('Registro realizado correctamente');
          $('#insert3').trigger("reset");
         }
         if (data!="true") {
            console.log(data);
            toastr.error('¡Hubo un error! Intente de nuevo');
            $('#insert3').trigger("reset");}}});});

$("#insert4").submit(function(e) {
e.preventDefault();
var form = $(this);
var url = form.attr('action');
var temp = form.serialize();
toastr.options = {
  "positionClass": "toast-top-center",
  "timeOut": "1500",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut"
}
$.ajax({
     type: "POST",
     url: url,
     data: form.serialize(), 
     success: function(data)
     {
      console.log(data);
         if (data=="true") {
          toastr.success('Registro realizado correctamente');
          $('#insert4').trigger("reset");
         }
         if (data!="true") {
            console.log(data);
            toastr.error('¡Hubo un error! Intente de nuevo');
            $('#insert4').trigger("reset");}}});});

$("#insert5").submit(function(e) {
e.preventDefault();
var form = $(this);
var url = form.attr('action');
var temp = form.serialize();
toastr.options = {
  "positionClass": "toast-top-center",
  "timeOut": "1500",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut"
}
$.ajax({
     type: "POST",
     url: url,
     data: form.serialize(), 
     success: function(data)
     {
      console.log(data);
         if (data=="true") {
          toastr.success('Registro realizado correctamente');
          $('#insert5').trigger("reset");
         }
         if (data!="true") {
            console.log(data);
            toastr.error('¡Hubo un error! Intente de nuevo');
            $('#insert5').trigger("reset");}}});});

$("#insert6").submit(function(e) {
e.preventDefault();
var form = $(this);
var url = form.attr('action');
var temp = form.serialize();
toastr.options = {
  "positionClass": "toast-top-center",
  "timeOut": "1500",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut"
}
$.ajax({
     type: "POST",
     url: url,
     data: form.serialize(), 
     success: function(data)
     {
      console.log(data);
         if (data=="true") {
          toastr.success('Registro realizado correctamente');
          $('#insert6').trigger("reset");
         }
         if (data!="true") {
            console.log(data);
            toastr.error('¡Hubo un error! Intente de nuevo');
            $('#insert6').trigger("reset");}}});});

$("#edituser").submit(function(e) {
e.preventDefault();
var form = $(this);
var url = form.attr('action');
var temp = form.serialize();
toastr.options = {
  "positionClass": "toast-top-center",
  "timeOut": "1500",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut"
}
$.ajax({
     type: "POST",
     url: url,
     data: form.serialize(), 
     success: function(data)
     {
      console.log(data);
         if (data=="true") {
          toastr.success('Usuario editado correctamente!');
          $('#edituser').trigger("reset");
         }
         if (data!="true") {
            console.log(data);
            toastr.error('¡Hubo un error! Intente de nuevo');
            $('#edituser').trigger("reset");}}});});

$("#borrar-registro").submit(function(e) {
e.preventDefault();
var form = $(this);
var url = form.attr('action');
var temp = form.serialize();
toastr.options = {
  "positionClass": "toast-top-center",
  "timeOut": "1500",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut"
}
$.ajax({
     type: "POST",
     url: url,
     data: form.serialize(), 
     success: function(data)
     {
      console.log(data);
         if (data=="true") {
          toastr.success('Registro Eliminado correctamente!');
          $('#borrar-registro').trigger("reset");
            setTimeout(function() {
                    location.reload(); // Recargar la página
                }, 2000); // Opcional: Recargar la página para actualizar la tabla
         }
         if (data!="true") {
            console.log(data);
            toastr.error('¡Hubo un error! Intente de nuevo');
            $('#borrar-registro').trigger("reset");}}});});
			
$('form[id^="actualizar"]').submit(function(e) {
    e.preventDefault();
    
    var form = $(this);  // Obtener el formulario específico
    var url = form.attr('action');
    
    toastr.options = {
      "positionClass": "toast-top-center",
      "timeOut": "1500",
      "showMethod": "fadeIn",
      "hideMethod": "fadeOut"
    }
    
    $.ajax({
        type: "POST",
        url: url,
        data: form.serialize(),
        success: function(data) {
            console.log(data);
            if (data == "true") {
                toastr.success('Registro actualizado correctamente');
                form.trigger("reset"); // Reiniciar el formulario
                setTimeout(function() {
                    location.reload(); // Recargar la página
                }, 2000); // Opcional: Recargar la página para actualizar la tabla
            } else {
                toastr.error('¡Hubo un error! Intente de nuevo');
            }
        }
    });
});



</script>

<!-- Toastr -->
<script src="assets/plugins/toastr/toastr.min.js"></script>
<!-- DataTables -->
<script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="assets/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
      integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
      crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
      integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
      crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.3/dist/Chart.min.js"
	
      integrity="sha256-R4pqcOYV8lt7snxMQO/HSbVCFRPMdrhAFMH+vr9giYI=" crossorigin="anonymous"></script>

</body>

</html>