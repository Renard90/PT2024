<?php
  session_start();
  include('modulo/conexion.php');
  include('modulo/validar.php');
?>
<?php include('includes/header.php'); ?>
<div class="d-flex" id="content-wrapper">
  <?php include('includes/sidebar.php'); ?>
  <!-- Page Content -->
  <div id="content" class="bg-grey">
    <section class="bg-light py-3">
      <div class="container">
        <div class="row">
          <div class="col-lg-9 col-md-8">
            <h1 class="font-weight-bold mb-0">Aplicación para la captura y genereacion del reporte de actividades de los profesores - LabTec</h1>
            <p class="lead text-muted">Laboratorio de Tecnologías Emergentes en Ciencias de la Computación</p>
          </div>
          <div class="col-lg-3 col-md-4 d-flex">
            <a data-toggle="modal" data-target="#view-modal" class="btn btn-primary align-self-center" href="#">Descargar reporte</a>
          </div>
        </div>
      </div>
    </section>
    
    
    <?php
      include('includes/tables/table_evaluacion.php');
      include('includes/tables/table_jcr.php');
      include('includes/tables/table_publicaciones.php');
      include('includes/tables/table_concluidos.php');
      include('includes/tables/table_vigentes.php');
      include('includes/tables/table_estancias.php');
      include('includes/tables/table_tesis.php');
      include('includes/tables/table_becarios.php');
      include('includes/tables/table_social.php');
      include('includes/tables/table_actividad.php');
      include('includes/tables/table_organizacion.php');
      include('includes/tables/table_plan.php');
      include('includes/tables/table_necesidad.php');
    ?>
    
    <div style="padding:1rem;"></div>
  </div>
</div>
<!-- Inicio Modal -->
<div class="modal fade" id="view-modal" meta charset="UTF-8">
	<div class="modal-dialog ">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Preparando Reporte...</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<div class="show-info modal-body">
				<form  action="" method="POST">
					<div class="card-body">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="name">Fecha inicial de captura</label><br>
									<input type="date" id="fecha1" name="fecha1" required />
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="name">Fecha final de captura</label><br>
									<input type="date"id="fecha2" name="fecha2" required />
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<a onclick="downForm();" class="btn btn-primary btn-sm form-control" href="#">Descargar</a>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- Fin Modal -->
<script src="assets/plugins/html2pdf.bundle.min.js"></script>
<script type="text/javascript">

function downForm(fecha1, fecha2) {
    fecha1 = $('#fecha1').val();
    fecha2 = $('#fecha2').val();
	if(fecha1 == ""||fecha2==""){
                  toastr.warning('las fechas no pueden estar vacias');
                }else{
	$.ajax({
		type: 'POST',
		url: 'reportes/pdf_reporte.php',
		data: {fecha1:fecha1,fecha2:fecha2},
		success: function(data) {
			generatePDF(data);
		}
				})};
}

function generatePDF (element) {
	var opt = {
		margin:       0.5,
		filename:     'Reporte General.pdf',
		image:        { type: 'jpeg', quality: 0.98 },
		html2canvas:  { scale: 1 },
		jsPDF:        { unit: 'in', format: 'letter',  }
	};
	html2pdf()
	.set(opt)
	.from(element)
	.save();
}
$( document ).ready(function() {
     $('#evaluacion').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true,
      "responsive": true
    });
});  
$( document ).ready(function() {
     $('#jcr').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true,
      "responsive": true
    });
});
$( document ).ready(function() {
     $('#publicaciones').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true,
      "responsive": true
    });
});
$( document ).ready(function() {
     $('#concluidos').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true,
      "responsive": true
    });
});
$( document ).ready(function() {
     $('#vigentes').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true,
      "responsive": true
    });
});
$( document ).ready(function() {
     $('#estancias').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true,
      "responsive": true
    });
});
$( document ).ready(function() {
     $('#tesis').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true,
      "responsive": true
    });
});
$( document ).ready(function() {
     $('#becarios').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true,
      "responsive": true
    });
});
$( document ).ready(function() {
     $('#social').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true,
      "responsive": true
    });
});
$( document ).ready(function() {
     $('#actividadactivartabla').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true,
      "responsive": true
    });
});
$( document ).ready(function() {
     $('#organizacion').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true,
      "responsive": true
    });
});
$( document ).ready(function() {
     $('#planactivartabla').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true,
      "responsive": true
    });
});
$( document ).ready(function() {
     $('#necesidadactivbartabla').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true,
      "responsive": true
    });
});
</script>
<?php include('includes/footer.php'); ?>