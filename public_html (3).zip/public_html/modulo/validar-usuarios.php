<?php
session_start();
include "conexion.php";
if($_POST['proceso']){
	$proceso		= $_POST['proceso'];
	if($proceso=="Iniciar"){
		$email 	= $_POST['email'];
		$password 		= sha1($_POST['password']);
		//Realizar consulta para ver si existe o no el usuario y clave
		$consulta	= " SELECT * FROM tbl_usuario WHERE correo='$email' AND password='$password'";
		$resultado	= mysqli_query($conexion, $consulta);
		$numusuario	= mysqli_num_rows($resultado);
		//leer datos
		$fila		= mysqli_fetch_array($resultado);
		$xID	= $fila['id'];
		$xNombre	= $fila['nombre'];
		$xApellido	= $fila['apellido'];
        $xCorreo  = $fila['correo'];
		if($numusuario>=1){
			$_SESSION['xID']	= $xID;
			$_SESSION['xNombre']	= $xNombre;
			$_SESSION['xApellido']	= $xApellido;
            $_SESSION['xCorreo']	= $xCorreo;
            
			echo "<script language='JavaScript'>location.href = '../index.php'</script>";
		}else{
            
			echo "<script language='JavaScript'>location.href = '../login.php'</script>";
		}
	}
}else{
	echo "<script language='JavaScript'>location.href = '../login.php'</script>";
}
?>

