<?php
 $xID   = $_SESSION['xID'];
 $xCorreo  = $_SESSION['xCorreo'];
 $xNombre  = $_SESSION['xNombre'];
 $xApellido  = $_SESSION['xApellido'];
if($xID ==""){
    echo "<script type='text/javascript'>
    window.location='../login.php';
    </script>"; 
}
?> 