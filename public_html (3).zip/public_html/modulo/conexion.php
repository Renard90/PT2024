<?php
  
  $user = "uoegjgqf_labtecco_database1";
  $pass = "QePxg2Cx9NJvLPKavAgL";
  $server = "localhost";
  $bd = "uoegjgqf_labtecco_database1";

  $conexion=mysqli_connect($server,$user,$pass,$bd);
  if(mysqli_connect_error()){
    echo "Fallo la conexion a la base de datos".mysqli_connect_error();
  }

?>