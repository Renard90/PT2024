<?php
include('../modulo/conexion.php');

$fecha1 = $_POST['fecha1'];
$fecha2 = $_POST['fecha2'];

$consulta2 = "SELECT * FROM tbl_publicaciones_jcr WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado2 = mysqli_query($conexion,$consulta2);

$consulta3 = "SELECT * FROM tbl_publicaciones WHERE tipo = 'otros indices' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado3 = mysqli_query($conexion,$consulta3);

$consulta4 = "SELECT * FROM tbl_publicaciones WHERE tipo = 'articulos divulgacion' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado4 = mysqli_query($conexion,$consulta4);

$consulta5 = "SELECT * FROM tbl_publicaciones WHERE tipo = 'congresos' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado5 = mysqli_query($conexion,$consulta5);

$consulta6 = "SELECT * FROM tbl_publicaciones WHERE tipo = 'capitulos libro' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado6 = mysqli_query($conexion,$consulta6);

while($row4 = mysqli_fetch_array($resultado4)){
    $nombre = utf8_decode($row4['nombre']);
    $autores = utf8_decode($row4['autores']);
    $paginas = $row4['paginas'];
    $publicacion = $row4['publicacion'];
    $lugar = utf8_decode($row4['lugar']);
    $link = base64_decode($row4['link']);
    
$output .='
Nombre del Artículo: '.$nombre.' 
Autores: '.$autores.' 
Página(s): '.$paginas.' 
Fecha de Publicación: '.$publicacion.' 
Nombre de la Revista: '.$lugar.' 
Link: '.$link.' 

';}
echo $output;

?>