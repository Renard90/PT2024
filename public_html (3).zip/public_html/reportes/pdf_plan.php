<?php
include('../modulo/conexion.php');

$fecha1 = $_POST['fecha1'];
$fecha2 = $_POST['fecha2'];

$consulta17 = "SELECT * FROM tbl_plan WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado17 = mysqli_query($conexion,$consulta17);


while($row17 = mysqli_fetch_array($resultado17)){
  $plan = base64_decode($row17['plan']);
  $inicio = $row17['inicio'];
  $fin = $row17['fin'];
  //$fecha = $row17['fecha'];
  //$usuario = utf8_decode($row17['usuario']);

$output .='
Plan de Trabajo: '.$plan.' 
Fecha de Inicio: '.$inicio.'  
Fecha de Fin: '.$fin.' 


';}

$output .='

';
echo $output;

?>





