<?php
include('../modulo/conexion.php');

$fecha1 = $_POST['fecha1'];
$fecha2 = $_POST['fecha2'];

$consulta2 = "SELECT * FROM tbl_publicaciones_jcr WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado2 = mysqli_query($conexion,$consulta2);

$consulta3 = "SELECT * FROM tbl_publicaciones WHERE tipo = 'otros indices' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado3 = mysqli_query($conexion,$consulta3);

$consulta4 = "SELECT * FROM tbl_publicaciones WHERE tipo = 'articulos divulgacion' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado4 = mysqli_query($conexion,$consulta4);

$consulta5 = "SELECT * FROM tbl_publicaciones WHERE tipo = 'congresos' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado5 = mysqli_query($conexion,$consulta5);

$consulta6 = "SELECT * FROM tbl_publicaciones WHERE tipo = 'capitulos libro' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado6 = mysqli_query($conexion,$consulta6);


    while($row2 = mysqli_fetch_array($resultado2)){
        $nombre = utf8_decode($row2['nombre']);
        $autores = utf8_decode($row2['autores']);
        $paginas = $row2['paginas'];
        $revista = utf8_decode($row2['revista']);
        $issn = $row2['issn'];
		$issn_electronico = $row2['issn_electronico'];
        $publicacion = $row2['publicacion'];
        $doi = base64_decode($row2['doi']);
        $link = base64_decode($row2['link']);
        
$output .='
Nombre del Artículo: '.$nombre.' 
Autore: '.$autores.' 
Página(s): '.$paginas.' 
Nombre de la Revista: '.$revista.' 
ISSN: '.$issn.' 
3ISSN Electronico: '.$issn_electronico.' 
Fecha de publicación: '.$publicacion.' 
DOI: '.$doi.' 
Link: '.$link.' 

';}
echo $output;

?>