<?php
include('../modulo/conexion.php');

$fecha1 = $_POST['fecha1'];
$fecha2 = $_POST['fecha2'];

$consulta16 = "SELECT * FROM tbl_organizacion WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado16 = mysqli_query($conexion,$consulta16);

while($row16 = mysqli_fetch_array($resultado16)){
  $nombre = utf8_decode($row16['nombre']);
  $proyecto = utf8_decode($row16['proyecto']);
  $inicio = $row16['inicio'];
  $fin = $row16['fin'];
  $institucion = utf8_decode($row16['institucion']);
  $fecha = $row16['fecha'];
  $usuario = utf8_decode($row16['usuario']);

$output .='
Nombre de las Académicas y/o Científicas : '.$nombre.' 
Nombre del Proyecto: '.$proyecto.' 
Fecha de Inicio: '.$inicio.' 
Fecha de Fin: '.$fin.' 
Institución: '.$institucion.' 

';}


$output .='

';



echo $output;

?>





