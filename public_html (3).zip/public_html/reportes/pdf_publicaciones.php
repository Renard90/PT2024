<?php
include('../modulo/conexion.php');

$fecha1 = $_POST['fecha1'];
$fecha2 = $_POST['fecha2'];

$consulta2 = "SELECT * FROM tbl_publicaciones_jcr WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado2 = mysqli_query($conexion,$consulta2);

$consulta3 = "SELECT * FROM tbl_publicaciones WHERE tipo = 'otros indices' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado3 = mysqli_query($conexion,$consulta3);

$consulta4 = "SELECT * FROM tbl_publicaciones WHERE tipo = 'articulos divulgacion' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado4 = mysqli_query($conexion,$consulta4);

$consulta5 = "SELECT * FROM tbl_publicaciones WHERE tipo = 'congresos' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado5 = mysqli_query($conexion,$consulta5);

$consulta6 = "SELECT * FROM tbl_publicaciones WHERE tipo = 'capitulos libro' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado6 = mysqli_query($conexion,$consulta6);

$output .='Artículos indizados en JCR
';

    while($row2 = mysqli_fetch_array($resultado2)){
        $nombre = utf8_decode($row2['nombre']);
        $autores = utf8_decode($row2['autores']);
        $paginas = $row2['paginas'];
        $revista = utf8_decode($row2['revista']);
        $issn = $row2['issn'];
		$issn_electronico = $row2['issn_electronico'];
        $publicacion = $row2['publicacion'];
        $doi = base64_decode($row2['doi']);
        $link = base64_decode($row2['link']);
        
$output .='
Nombre del Artículo: '.$nombre.' 
Autore: '.$autores.' 
Página(s): '.$paginas.' 
Nombre de la Revista: '.$revista.' 
ISSN: '.$issn.' 
3ISSN Electronico: '.$issn_electronico.' 
Fecha de publicación: '.$publicacion.' 
DOI: '.$doi.' 
Link: '.$link.' 

';}

$output .='Artículos en Otros Índices
';

while($row3 = mysqli_fetch_array($resultado3)){
    $nombre = utf8_decode($row3['nombre']);
    $autores = utf8_decode($row3['autores']);
    $paginas = $row3['paginas'];
    $publicacion = $row3['publicacion'];
    $lugar = utf8_decode($row3['lugar']);
    $link = base64_decode($row3['link']);
    
$output .='
Nombre del Artículo: '.$nombre.' 
Autore: '.$autores.' 
Página(s): '.$paginas.' 
Fecha de Publicación: '.$publicacion.' 
Nombre de la Revista: '.$lugar.' 
Link: '.$link.' 

';}

$output .='Artículos de Divulgación
';

while($row4 = mysqli_fetch_array($resultado4)){
    $nombre = utf8_decode($row4['nombre']);
    $autores = utf8_decode($row4['autores']);
    $paginas = $row4['paginas'];
    $publicacion = $row4['publicacion'];
    $lugar = utf8_decode($row4['lugar']);
    $link = base64_decode($row4['link']);
    
$output .='
Nombre del Artículo: '.$nombre.' 
Autores: '.$autores.' 
Página(s): '.$paginas.' 
Fecha de Publicación: '.$publicacion.' 
Nombre de la Revista: '.$lugar.' 
Link: '.$link.' 

';}

$output .='Congresos Internacionales y Nacionales
';

while($row5 = mysqli_fetch_array($resultado5)){
    $nombre = utf8_decode($row5['nombre']);
    $autores = utf8_decode($row5['autores']);
    $paginas = $row5['paginas'];
    $publicacion = $row5['publicacion'];
    $lugar = utf8_decode($row5['lugar']);
    
$output .='
Título del trabajo presentado: '.$nombre.' 
Autore(s): '.$autores.' 
Página(s): '.$paginas.'  
Fecha de Publicación: '.$publicacion.' 
Nombre del Congreso: '.$lugar.' 

';}

$output .='Capítulos de Libro
';

while($row6 = mysqli_fetch_array($resultado6)){
    $nombre = utf8_decode($row6['nombre']);
    $autores = utf8_decode($row6['autores']);
    $paginas = $row6['paginas'];
    $publicacion = $row6['publicacion'];
    $lugar = utf8_decode($row6['lugar']);
    $link = base64_decode($row6['link']);
    
$output .='
Capítulo del libro: '.$nombre.' 
Autores: '.$autores.' 
Página(s): '.$paginas.' 
Fecha de Publicación: '.$publicacion.' 
Título del Libro: '.$lugar.' 
ISBN: '.$link.' 

';}



$output .='

';



echo $output;

?>