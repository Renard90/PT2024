<?php
include('../modulo/conexion.php');

$fecha1 = $_POST['fecha1'];
$fecha2 = $_POST['fecha2'];

$consulta9 = "SELECT * FROM tbl_estancias WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado9 = mysqli_query($conexion,$consulta9);
$output .='
';
while($row9 = mysqli_fetch_array($resultado9)){
  $nombre = utf8_decode($row9['nombre']);
  $proyecto = utf8_decode($row9['proyecto']);
  $autores = utf8_decode($row9['autores']);
  $institucion = utf8_decode($row9['institucion']);
  $estancias = utf8_decode($row9['estancias']);
  $fecha = $row9['fecha'];
  $usuario = utf8_decode($row9['usuario']);

$output .='
Nombre: '.$nombre.' 
Nombre del Proyecto: '.$proyecto.' 
Autores: '.$autores.' 
Institución: '.$institucion.' 
Estancias: '.$estancias.' 

';}



$output .='

';



echo $output;

?>





