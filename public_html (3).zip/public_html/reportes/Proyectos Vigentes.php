<?php
include('../modulo/conexion.php');

$fecha1 = $_POST['fecha1'];
$fecha2 = $_POST['fecha2'];

$consulta7 = "SELECT * FROM tbl_proyectos_concluidos WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado7 = mysqli_query($conexion,$consulta7);

$consulta8 = "SELECT * FROM tbl_proyectos_vigente WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado8 = mysqli_query($conexion,$consulta8);

while($row8 = mysqli_fetch_array($resultado8)){
  $proyecto = utf8_decode($row8['proyecto']);
  $nombre = utf8_decode($row8['nombre']);
  $autores = utf8_decode($row8['autores']);
  $fecha_inicio = $row8['fecha_inicio'];
  $fecha_fin = $row8['fecha_fin'];
  $institucion = utf8_decode($row8['institucion']);
  $estado = utf8_decode($row8['estado']);
  
$output .='
Nombre de la organización que otorgó el financiamiento: '.$proyecto.' 
Nombre del Proyecto: '.$nombre.' 
Participantes: '.$autores.' 
Inicio: '.$fecha_inicio.' 
Termino: '.$fecha_fin.' 
Institución: '.$institucion.' 

';}


$output .='

';
echo $output;
?>