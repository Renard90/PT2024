<?php
include('../modulo/conexion.php');

$fecha1 = $_POST['fecha1'];
$fecha2 = $_POST['fecha2'];
$total=0;

$consulta = "SELECT * FROM tbl_evaluacion WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado = mysqli_query($conexion,$consulta);
    while($row = mysqli_fetch_array($resultado)){
        $actividad = base64_decode($row['actividad']);
		$total=$total+1;
        
$output .='Actividad '.$total.': '
.$actividad.'

';}
echo $output;

?>





