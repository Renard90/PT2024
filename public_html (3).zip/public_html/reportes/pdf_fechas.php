<?php
include('../modulo/conexion.php');

$fecha1 = $_POST['fecha1'];
$fecha2 = $_POST['fecha2'];

$output = '

Del día: '.$fecha1.' al día: '.$fecha2.'
';
    
echo $output;

?>





