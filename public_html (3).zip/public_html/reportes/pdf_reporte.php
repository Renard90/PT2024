<?php
include('../modulo/conexion.php');

$fecha1 = $_POST['fecha1'];
$fecha2 = $_POST['fecha2'];

$consulta = "SELECT * FROM tbl_evaluacion WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado = mysqli_query($conexion,$consulta);

$consulta2 = "SELECT * FROM tbl_publicaciones_jcr WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado2 = mysqli_query($conexion,$consulta2);

$consulta3 = "SELECT * FROM tbl_publicaciones WHERE tipo = 'otros indices' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado3 = mysqli_query($conexion,$consulta3);

$consulta4 = "SELECT * FROM tbl_publicaciones WHERE tipo = 'articulos divulgacion' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado4 = mysqli_query($conexion,$consulta4);

$consulta5 = "SELECT * FROM tbl_publicaciones WHERE tipo = 'congresos' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado5 = mysqli_query($conexion,$consulta5);

$consulta6 = "SELECT * FROM tbl_publicaciones WHERE tipo = 'capitulos libro' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado6 = mysqli_query($conexion,$consulta6);

$consulta7 = "SELECT * FROM tbl_proyectos_concluidos WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado7 = mysqli_query($conexion,$consulta7);

$consulta8 = "SELECT * FROM tbl_proyectos_vigente WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado8 = mysqli_query($conexion,$consulta8);

$consulta9 = "SELECT * FROM tbl_estancias WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado9 = mysqli_query($conexion,$consulta9);

$consulta10 = "SELECT * FROM tbl_tesis WHERE tipo = 'Licenciatura' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado10 = mysqli_query($conexion,$consulta10);

$consulta11 = "SELECT * FROM tbl_tesis WHERE tipo = 'Maestria' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado11 = mysqli_query($conexion,$consulta11);

$consulta12 = "SELECT * FROM tbl_tesis WHERE tipo = 'Doctorado' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado12 = mysqli_query($conexion,$consulta12);

$consulta13 = "SELECT * FROM tbl_becarios WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado13 = mysqli_query($conexion,$consulta13);

$consulta14 = "SELECT * FROM tbl_servicio_actividad WHERE tipo = 'Servicio Social' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado14 = mysqli_query($conexion,$consulta14);

$consulta15 = "SELECT * FROM tbl_servicio_actividad WHERE tipo = 'Actividad' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado15 = mysqli_query($conexion,$consulta15);

$consulta16 = "SELECT * FROM tbl_organizacion WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado16 = mysqli_query($conexion,$consulta16);

$consulta17 = "SELECT * FROM tbl_plan WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado17 = mysqli_query($conexion,$consulta17);

$consulta18 = "SELECT * FROM tbl_necesidad WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado18 = mysqli_query($conexion,$consulta18);



$output = '

<!DOCTYPE html>

<html>

<head>

<title></title>

        <meta charset="utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

        <style>

        .header {text-align: center;}

        .header img {

          max-width: 100px;

        }

        .titleStrong{

          color: #382AB9; 

          font-size: 35px;

        }



        .title{

          text-align: center;

          font-weigh:800;

        }

        .title p {

          font-size: 22px;

        }



        .td-25{

    width: 25%;

}

.td-50{

    width: 50%;

}

.td-100{

    width: 100%;

}

    </style>



    <style type="text/css">

.tg  {border-collapse:collapse;border-color:#9ABAD9;border-spacing:0;margin:0px auto;}

.tg td{background-color:#EBF5FF;border-color:#9ABAD9;border-style:solid;border-width:1px;color:#444;

  font-family:Arial, sans-serif;font-size:14px;overflow:hidden;padding:10px 5px;word-break:normal;}

.tg th{background-color:transparent;border-color:transparent;border-style:solid;border-width:1px;color:#000;

  font-family:Arial, sans-serif;font-size:14px;font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}

.tg .tg-oejs{background-color:transparent;border-color:transparent;text-align:center;vertical-align:top; font-size:9px;}

.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top; font-size:12px;}

@media screen and (max-width: 767px) {.tg {width: auto !important;}.tg col {width: auto !important;}.tg-wrap {overflow-x: auto;-webkit-overflow-scrolling: touch;margin: auto 0px;}}

</style>

</head>

 <body>



  <div class="container">
    <div style="" class="row">
      <div class="col-md-12" style="text-align: center;">
      <p class="titleStrong" style="font-size: 25px;line-height: 100%;"><b>Reporte General</b></p><br>
      <p>Del Día: '.$fecha1.' Al Día: '.$fecha2.' <br>
      </div> 
    </div> 
    <br>';
    $output .='</div><div class="container">

    <div style="width:100%;" class="row">
    <div class="col-md-12" style="text-align: center;">
        <b>Índices de Evaluación e Impacto de la Calidad Investigadora</b><br>
    </div>
    </div> 
    <p>
';

    while($row = mysqli_fetch_array($resultado)){
        $actividad = base64_decode($row['actividad']);
        
$output .='</div></div><div class="container">

   <div style="width:100%;" class="row">

  <p>

<b>Actividad:</b> '.$actividad.' <br>

';}

$output .='</div></div><div class="container">

    <div style="width:100%;" class="row">
    <div class="col-md-12" style="text-align: center;">
        <b>Artículos indizados en JCR</b><br>
    </div> 
    </div>
    <p>
';

    while($row2 = mysqli_fetch_array($resultado2)){
        $nombre = utf8_decode($row2['nombre']);
        $autores = utf8_decode($row2['autores']);
        $paginas = $row2['paginas'];
        $revista = utf8_decode($row2['revista']);
        $issn = $row2['issn'];
		$issn_electronico = $row2['issn_electronico'];
        $publicacion = $row2['publicacion'];
        $doi = base64_decode($row2['doi']);
        $link = base64_decode($row2['link']);
        
$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
  <p>

<b>Nombre del Artículo:</b> '.$nombre.' <br>
<b>Autores:</b> '.$autores.' <br>
<b>Páginas:</b> '.$paginas.' <br>
<b>Nombre de la Revista:</b> '.$revista.' <br>
<b>ISSN:</b> '.$issn.' <br>
<b>ISSN Electronico:</b> '.$issn_electronico.' <br>
<b>Fecha de publicación:</b> '.$publicacion.' <br>
<b>DOI:</b> '.$doi.' <br>
<b>Link:</b> '.$link.' <br>

';}

$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<div class="col-md-12" style="text-align: center;">
<b>Artículos en Otros Índices</b><br>
</div> 
</div>
<p>
';

while($row3 = mysqli_fetch_array($resultado3)){
    $nombre = utf8_decode($row3['nombre']);
    $autores = utf8_decode($row3['autores']);
    $paginas = $row3['paginas'];
    $publicacion = $row3['publicacion'];
    $lugar = utf8_decode($row3['lugar']);
    $link = base64_decode($row3['link']);
    
$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<p>

<b>Nombre del Artículo:</b> '.$nombre.' <br>
<b>Autores:</b> '.$autores.' <br>
<b>Páginas:</b> '.$paginas.' <br>
<b>Fecha de Publicación:</b> '.$publicacion.' <br>
<b>Lugar de Publicación:</b> '.$lugar.' <br>
<b>Link:</b> '.$link.' <br>

';}

$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<div class="col-md-12" style="text-align: center;">
    <b>Artículos de Divulgación</b><br>
</div> 
</div>
<p>
';

while($row4 = mysqli_fetch_array($resultado4)){
    $nombre = utf8_decode($row4['nombre']);
    $autores = utf8_decode($row4['autores']);
    $paginas = $row4['paginas'];
    $publicacion = $row4['publicacion'];
    $lugar = utf8_decode($row4['lugar']);
    $link = base64_decode($row4['link']);
    
$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<p>

<b>Nombre del Artículo:</b> '.$nombre.' <br>
<b>Autores:</b> '.$autores.' <br>
<b>Páginas:</b> '.$paginas.' <br>
<b>Fecha de Publicación:</b> '.$publicacion.' <br>
<b>Lugar de Publicación:</b> '.$lugar.' <br>
<b>Link:</b> '.$link.' <br>

';}

$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<div class="col-md-12" style="text-align: center;">
    <b>Congresos Internacionales y Nacionales</b><br>
</div>
</div> 
<p>
';

while($row5 = mysqli_fetch_array($resultado5)){
    $nombre = utf8_decode($row5['nombre']);
    $autores = utf8_decode($row5['autores']);
    $paginas = $row5['paginas'];
    $publicacion = $row5['publicacion'];
    $lugar = utf8_decode($row5['lugar']);
    
$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<p>

<b>Nombre del Congreso:</b> '.$nombre.' <br>
<b>Autores:</b> '.$autores.' <br>
<b>Páginas:</b> '.$paginas.' <br>
<b>Fecha de Publicación:</b> '.$publicacion.' <br>
<b>Lugar de Publicación:</b> '.$lugar.' <br>

';}

$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<div class="col-md-12" style="text-align: center;">
    <b>Capítulos de Libro</b><br>
</div> 
</div>
<p>
';

while($row6 = mysqli_fetch_array($resultado6)){
    $nombre = utf8_decode($row6['nombre']);
    $autores = utf8_decode($row6['autores']);
    $paginas = $row6['paginas'];
    $publicacion = $row6['publicacion'];
    $lugar = utf8_decode($row6['lugar']);
    $link = base64_decode($row6['link']);
    
$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<p>

<b>Capítulo del libro:</b> '.$nombre.' <br>
<b>Autores:</b> '.$autores.' <br>
<b>Páginas:</b> '.$paginas.' <br>
<b>Fecha de Publicación:</b> '.$publicacion.' <br>
<b>Lugar de Publicación:</b> '.$lugar.' <br>
<b>Link:</b> '.$link.' <br>

';}

$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<div class="col-md-12" style="text-align: center;">
    <b>Proyectos Concluidos</b><br>
</div> 
</div>
<p>
';

while($row7 = mysqli_fetch_array($resultado7)){
  $proyecto = utf8_decode($row7['proyecto']);
  $nombre = utf8_decode($row7['nombre']);
  $autores = utf8_decode($row7['autores']);
  $fecha_inicio = $row7['fecha_inicio'];
  $fecha_fin = $row7['fecha_fin'];
  $institucion = utf8_decode($row7['institucion']);
  $estado = utf8_decode($row7['estado']);
  
$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<p>

<b>Proyecto:</b> '.$proyecto.' <br>
<b>Nombre del Proyecto:</b> '.$nombre.' <br>
<b>Autores:</b> '.$autores.' <br>
<b>Inicio:</b> '.$fecha_inicio.' <br>
<b>Termino:</b> '.$fecha_fin.' <br>
<b>Institución:</b> '.$institucion.' <br>

';}

$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<div class="col-md-12" style="text-align: center;">
    <b>Proyectos Vigentes</b><br>
</div> 
</div>
<p>
';

while($row8 = mysqli_fetch_array($resultado8)){
  $proyecto = utf8_decode($row8['proyecto']);
  $nombre = utf8_decode($row8['nombre']);
  $autores = utf8_decode($row8['autores']);
  $fecha_inicio = $row8['fecha_inicio'];
  $fecha_fin = $row8['fecha_fin'];
  $institucion = utf8_decode($row8['institucion']);
  $estado = utf8_decode($row8['estado']);
  
$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<p>

<b>Proyecto:</b> '.$proyecto.' <br>
<b>Nombre del Proyecto:</b> '.$nombre.' <br>
<b>Participantes:</b> '.$autores.' <br>
<b>Inicio:</b> '.$fecha_inicio.' <br>
<b>Termino:</b> '.$fecha_fin.' <br>
<b>Institución:</b> '.$institucion.' <br>

';}

$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<div class="col-md-12" style="text-align: center;">
    <b>Estancias Académicas</b><br>
</div> 
</div>
<p>
';

while($row9 = mysqli_fetch_array($resultado9)){
  $nombre = utf8_decode($row9['nombre']);
  $proyecto = utf8_decode($row9['proyecto']);
  $autores = utf8_decode($row9['autores']);
  $institucion = utf8_decode($row9['institucion']);
  $estancias = utf8_decode($row9['estancias']);
  
$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<p>

<b>Nombre:</b> '.$nombre.' <br>
<b>Nombre del Proyecto:</b> '.$proyecto.' <br>
<b>Autores:</b> '.$autores.' <br>
<b>Institución:</b> '.$institucion.' <br>
<b>Estancias:</b> '.$estancias.' <br>

';}

$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<div class="col-md-12" style="text-align: center;">
    <b>Tesis Licenciatura</b><br>
</div> 
</div>
<p>
';

while($row10 = mysqli_fetch_array($resultado10)){
  $nombre = utf8_decode($row10['nombre']);
  $autor = utf8_decode($row10['autor']);
  $fecha_tesis = $row10['fecha_tesis'];
  $institucion = utf8_decode($row10['institucion']);
  $programa = utf8_decode($row10['programa']);
  $estado = $row10['estado'];
  
$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<p>

<b>Nombre de la Tesis:</b> '.$nombre.' <br>
<b>Nombre del Autor:</b> '.$autor.' <br>
<b>Fecha:</b> '.$fecha_tesis.' <br>
<b>Institución:</b> '.$institucion.' <br>
<b>Programa:</b> '.$programa.' <br>
<b>Estado de la Tesis:</b> '.$estado.' <br>

';}

$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<div class="col-md-12" style="text-align: center;">
    <b>Tesis Maestría</b><br>
</div> 
</div>
<p>
';

while($row11 = mysqli_fetch_array($resultado11)){
  $nombre = utf8_decode($row11['nombre']);
  $autor = utf8_decode($row11['autor']);
  $fecha_tesis = $row11['fecha_tesis'];
  $institucion = utf8_decode($row11['institucion']);
  $programa = utf8_decode($row11['programa']);
  $estado = $row11['estado'];
  
$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<p>

<b>Nombre de la Tesis:</b> '.$nombre.' <br>
<b>Nombre del Autor:</b> '.$autor.' <br>
<b>Fecha:</b> '.$fecha_tesis.' <br>
<b>Institución:</b> '.$institucion.' <br>
<b>Programa:</b> '.$programa.' <br>
<b>Estado de la Tesis:</b> '.$estado.' <br>

';}

$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<div class="col-md-12" style="text-align: center;">
    <b>Tesis Doctorado</b><br>
</div> 
</div>
<p>
';

while($row12 = mysqli_fetch_array($resultado12)){
  $nombre = utf8_decode($row12['nombre']);
  $autor = utf8_decode($row12['autor']);
  $fecha_tesis = $row12['fecha_tesis'];
  $institucion = utf8_decode($row12['institucion']);
  $programa = utf8_decode($row12['programa']);
  $estado = $row12['estado'];
  
$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<p>

<b>Nombre de la Tesis:</b> '.$nombre.' <br>
<b>Nombre del Autor:</b> '.$autor.' <br>
<b>Fecha:</b> '.$fecha_tesis.' <br>
<b>Institución:</b> '.$institucion.' <br>
<b>Programa:</b> '.$programa.' <br>
<b>Estado de la Tesis:</b> '.$estado.' <br>

';}

$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<div class="col-md-12" style="text-align: center;">
    <b>Formación de Recursos Humanos - Becarios</b><br>
</div> 
</div>
<p>
';

while($row13 = mysqli_fetch_array($resultado13)){
  $nombre = utf8_decode($row13['nombre']);
  $proyecto = utf8_decode($row13['proyecto']);
  $inicio = $row13['inicio'];
  $fin = $row13['fin'];
  
$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<p>

<b>Nombre del Becario:</b> '.$nombre.' <br>
<b>Proyecto:</b> '.$proyecto.' <br>
<b>Fecha de Inicio:</b> '.$inicio.' <br>
<b>Fecha de Fin:</b> '.$fin.' <br>

';}

$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<div class="col-md-12" style="text-align: center;">
    <b>Formación de Recursos Humanos - Servicio Social</b><br>
</div> 
</div>
<p>
';

while($row14 = mysqli_fetch_array($resultado14)){
  $nombre = utf8_decode($row14['nombre']);
  $proyecto = utf8_decode($row14['proyecto']);
  $programa = $row14['programa'];
  $inicio = $row14['inicio'];
  $fin = $row14['fin'];
  
$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<p>

<b>Nombre del Alumno:</b> '.$nombre.' <br>
<b>Nombre del Proyecto:</b> '.$proyecto.' <br>
<b>Programa:</b> '.$programa.' <br>
<b>Fecha de Inicio:</b> '.$inicio.' <br>
<b>Fecha de Fin:</b> '.$fin.' <br>

';}

$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<div class="col-md-12" style="text-align: center;">
    <b>Actividad de Estudiantes en Eventos Académicos Nacionales e Internacionales</b><br>
</div> 
</div>
<p>
';

while($row15 = mysqli_fetch_array($resultado15)){
  $nombre = utf8_decode($row15['nombre']);
  $proyecto = utf8_decode($row15['proyecto']);
  $programa = $row15['programa'];
  $inicio = $row15['inicio'];
  $fin = $row15['fin'];
  
$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<p>

<b>Nombre del Alumno:</b> '.$nombre.' <br>
<b>Nombre del Proyecto:</b> '.$proyecto.' <br>
<b>Programa:</b> '.$programa.' <br>
<b>Fecha de Inicio:</b> '.$inicio.' <br>
<b>Fecha de Fin:</b> '.$fin.' <br>

';}

$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<div class="col-md-12" style="text-align: center;">
    <b>Organización de Actividades</b><br>
</div> 
</div>
<p>
';

while($row16 = mysqli_fetch_array($resultado16)){
  $nombre = utf8_decode($row16['nombre']);
  $proyecto = utf8_decode($row16['proyecto']);
  $inicio = $row16['inicio'];
  $fin = $row16['fin'];
  $institucion = utf8_decode($row16['institucion']);
  
$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<p>

<b>Nombre de las Académicas y/o Científicas :</b> '.$nombre.' <br>
<b>Nombre del Proyecto:</b> '.$proyecto.' <br>
<b>Fecha de Inicio:</b> '.$inicio.' <br>
<b>Fecha de Fin:</b> '.$fin.' <br>
<b>Institución:</b> '.$institucion.' <br>

';}

$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<div class="col-md-12" style="text-align: center;">
    <b>Plan de Trabajo</b><br>
</div> 
</div>
<p>
';

while($row17 = mysqli_fetch_array($resultado17)){
  $plan = base64_decode($row17['plan']);
  $inicio = $row17['inicio'];
  $fin = $row17['fin'];
  
$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<p>

<b>Plan de Trabajo:</b> '.$plan.' <br>
<b>Fecha de Inicio:</b> '.$inicio.' <br>
<b>Fecha de Fin:</b> '.$fin.' <br>

';}

$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<div class="col-md-12" style="text-align: center;">
    <b>Necesidad de Fortalecimiento de Infraestructura</b><br>
</div> 
</div>
<p>
';

while($row18 = mysqli_fetch_array($resultado18)){
  $necesidad = base64_decode($row18['necesidad']);
  
$output .='</div></div><div class="container">

<div style="width:100%;" class="row">
<p>

<b>Necesidades prioritarias para la operación del laboratorio:</b><br> '.$necesidad.' <br>

';}

$output .='

  </div>

</div>

  </body>

  </html>

';



echo $output;

?>





