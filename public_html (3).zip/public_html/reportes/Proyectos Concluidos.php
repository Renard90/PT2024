<?php
include('../modulo/conexion.php');

$fecha1 = $_POST['fecha1'];
$fecha2 = $_POST['fecha2'];

$consulta7 = "SELECT * FROM tbl_proyectos_concluidos WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado7 = mysqli_query($conexion,$consulta7);

$consulta8 = "SELECT * FROM tbl_proyectos_vigente WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado8 = mysqli_query($conexion,$consulta8);

while($row7 = mysqli_fetch_array($resultado7)){
  $proyecto = utf8_decode($row7['proyecto']);
  $nombre = utf8_decode($row7['nombre']);
  $autores = utf8_decode($row7['autores']);
  $fecha_inicio = $row7['fecha_inicio'];
  $fecha_fin = $row7['fecha_fin'];
  $institucion = utf8_decode($row7['institucion']);
  $estado = utf8_decode($row7['estado']);
  
$output .='
Nombre de la organización que otorgó el financiamiento:</b> '.$proyecto.' <br>
Nombre del Proyecto: '.$nombre.' 
Participantes: '.$autores.' 
Inicio: '.$fecha_inicio.' 
Termino: '.$fecha_fin.' 
Institución: '.$institucion.'

';}
echo $output;
?>