<?php
include('../modulo/conexion.php');

$fecha1 = $_POST['fecha1'];
$fecha2 = $_POST['fecha2'];

$consulta10 = "SELECT * FROM tbl_tesis WHERE tipo = 'Licenciatura' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado10 = mysqli_query($conexion,$consulta10);

$consulta11 = "SELECT * FROM tbl_tesis WHERE tipo = 'Maestria' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado11 = mysqli_query($conexion,$consulta11);

$consulta12 = "SELECT * FROM tbl_tesis WHERE tipo = 'Doctorado' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado12 = mysqli_query($conexion,$consulta12);

$consulta13 = "SELECT * FROM tbl_becarios WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado13 = mysqli_query($conexion,$consulta13);

$consulta14 = "SELECT * FROM tbl_servicio_actividad WHERE tipo = 'Servicio Social' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado14 = mysqli_query($conexion,$consulta14);

$consulta15 = "SELECT * FROM tbl_servicio_actividad WHERE tipo = 'Actividad' AND (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado15 = mysqli_query($conexion,$consulta15);
$output .='Tesis Licenciatura
';

while($row10 = mysqli_fetch_array($resultado10)){
  $nombre = utf8_decode($row10['nombre']);
  $autor = utf8_decode($row10['autor']);
  $fecha_tesis = $row10['fecha_tesis'];
  $institucion = utf8_decode($row10['institucion']);
  $programa = utf8_decode($row10['programa']);
  $estado = $row10['estado'];
  $fecha = $row10['fecha'];
  $usuario = utf8_decode($row10['usuario']);

$output .='
Nombre de la Tesis: '.$nombre.' 
Nombre del Alumno: '.$autor.' 
Fecha: '.$fecha_tesis.' 
Institución: '.$institucion.' 
Programa: '.$programa.' 
Estado de la Tesis: '.$estado.'

';}

$output .='Tesis Maestría
';

while($row11 = mysqli_fetch_array($resultado11)){
  $nombre = utf8_decode($row11['nombre']);
  $autor = utf8_decode($row11['autor']);
  $fecha_tesis = $row11['fecha_tesis'];
  $institucion = utf8_decode($row11['institucion']);
  $programa = utf8_decode($row11['programa']);
  $estado = $row11['estado'];
  $fecha = $row11['fecha'];
  $usuario = utf8_decode($row11['usuario']);

$output .='
Nombre de la Tesis: '.$nombre.' 
Nombre del Alumno: '.$autor.' 
Fecha: '.$fecha_tesis.'
Institución:'.$institucion.' 
Programa: '.$programa.' 
Estado de la Tesis: '.$estado.' 

';}

$output .='Tesis Doctorado
';

while($row12 = mysqli_fetch_array($resultado12)){
  $nombre = utf8_decode($row12['nombre']);
  $autor = utf8_decode($row12['autor']);
  $fecha_tesis = $row12['fecha_tesis'];
  $institucion = utf8_decode($row12['institucion']);
  $programa = utf8_decode($row12['programa']);
  $estado = $row12['estado'];
  $fecha = $row12['fecha'];
  $usuario = utf8_decode($row12['usuario']);

$output .='
Nombre de la Tesis: '.$nombre.' 
Nombre del Alumno: '.$autor.' 
Fecha: '.$fecha_tesis.' 
Institución: '.$institucion.' 
Programa: '.$programa.' 
Estado de la Tesis: '.$estado.' 

';}

$output .='Becarios
';

while($row13 = mysqli_fetch_array($resultado13)){
  $nombre = utf8_decode($row13['nombre']);
  $proyecto = utf8_decode($row13['proyecto']);
  $inicio = $row13['inicio'];
  $fin = $row13['fin'];
  $fecha = $row13['fecha'];
  $usuario = utf8_decode($row13['usuario']);

$output .='
Nombre del Becario: '.$nombre.' 
Proyecto: '.$proyecto.' 
Fecha de Inicio: '.$inicio.' 
Fecha de Fin: '.$fin.' 

';}

$output .='Servicio Social
';

while($row14 = mysqli_fetch_array($resultado14)){
  $nombre = utf8_decode($row14['nombre']);
  $proyecto = utf8_decode($row14['proyecto']);
  $programa = $row14['programa'];
  $inicio = $row14['inicio'];
  $fin = $row14['fin'];
  $fecha = $row14['fecha'];
  $usuario = utf8_decode($row14['usuario']);

$output .='
Nombre del Alumno: '.$nombre.' 
Nombre del Proyecto: '.$proyecto.' 
Programa: '.$programa.'  
Fecha de Inicio: '.$inicio.' 
Fecha de Fin: '.$fin.' 

';}

$output .='Actividad de Estudiantes en Eventos Académicos Nacionales e Internacionales
';

while($row15 = mysqli_fetch_array($resultado15)){
  $nombre = utf8_decode($row15['nombre']);
  $proyecto = utf8_decode($row15['proyecto']);
  $programa = $row15['programa'];
  $inicio = $row15['inicio'];
  $fin = $row15['fin'];
  $fecha = $row15['fecha'];
  $usuario = utf8_decode($row15['usuario']);

$output .='
Nombre del Alumno: '.$nombre.' 
Ponencia: '.$proyecto.' 
Programa: '.$programa.' 
Fecha de Inicio: '.$inicio.' 

';}

$output .='

';



echo $output;

?>





