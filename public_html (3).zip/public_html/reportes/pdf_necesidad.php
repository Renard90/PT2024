<?php
include('../modulo/conexion.php');

$fecha1 = $_POST['fecha1'];
$fecha2 = $_POST['fecha2'];

$consulta18 = "SELECT * FROM tbl_necesidad WHERE (fecha BETWEEN '$fecha1' AND '$fecha2') ORDER BY fecha ASC;";
$resultado18 = mysqli_query($conexion,$consulta18);

while($row18 = mysqli_fetch_array($resultado18)){
  $necesidad = base64_decode($row18['necesidad']);
  $fecha = $row18['fecha'];
  $usuario = utf8_decode($row18['usuario']);

$output .='
Necesidades prioritarias para la operación del laboratorio: '.$necesidad.' 

';}

$output .='

  
';



echo $output;

?>





