<?php
  session_start();
  include('modulo/conexion.php');
  include('modulo/validar.php');

  $id = $_SESSION['xID'];
  $nombre = $_SESSION['xNombre'];
  $apellido = $_SESSION['xApellido'];
  $usuario = $nombre." ".$apellido;
 
?>
<?php include('includes/header.php'); ?>
<div class="d-flex" id="content-wrapper">
    <?php include('includes/sidebar.php'); ?>
    <!-- Page Content -->
    <div id="content" class="bg-grey w-100">
        <section class="bg-light py-3">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-md-8">
                        <h1 class="font-weight-bold mb-0"> Índices de Evaluación e Impacto de la Calidad Investigadora</h1>
                    </div>
                    <div class="col-lg-3 col-md-4 d-flex">
                        <a data-toggle="modal" data-target="#view-modal" class="btn btn-primary w-100 align-self-center" href="#">Descargar reporte</a>
                    </div>
                </div>
            </div>
        </section>
        <!-- Plan de Trabajo -->
        <section>
            <div class="container">
                <div class="row">
                    <!-- Margen anchura del cuadro FORM -->
                    <div class="col-lg-10 my-3">
                        <!-- Margen del cuadro FORM -->
                        <div class="card rounded-0">
                            <div class="card-header bg-light">
                                <h6 class="font-weight-bold mb-0">En este apartado puede incluir información sobre la calidad investigadora por Google Scholar, Journal Catations Reports y Sistema Nacional de Investigadores</h6>
                            </div>
                            <div class="card-body">
                                <!-- Formulario -->
                                <form id="insert" action="process/insert_evaluacion.php" method="POST">
								<input type="hidden" value="<?php echo $usuario; ?>" name="usuario">
                                    <div class="form-group">
                                        <textarea required class="form-control" id="exampleFormControlTextarea1" name="actividad" id="actividad" rows="3"></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Done</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<!-- Inicio Modal -->
<div class="modal fade" id="view-modal">
	<div class="modal-dialog ">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Preparando Reporte...</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<div class="show-info modal-body">
				<form  action="" method="POST">
					<div class="card-body">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="name">Fecha inicial de captura</label><br>
									<input required type="date" id="fecha1" name="fecha1">
								</div>
							</div>
						</div>
					
					
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="name">Fecha final de captura</label><br>
									<input required type="date"id="fecha2" name="fecha2">
								</div>
							</div>
						</div>
					
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<a onclick="downForm();" class="btn btn-primary btn-sm form-control" href="#">Descargar</a>
								</div>
							</div>
						</div>
					
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- Fin Modal -->
<script src="assets/plugins/html2pdf.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.70/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.0.272/jspdf.debug.js"></"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.70/vfs_fonts.js"></script>
<script type="text/javascript">

function downForm(fecha1, fecha2) {
    fecha1 = $('#fecha1').val();
    fecha2 = $('#fecha2').val();

    if (fecha1 == "" || fecha2 == "") {
        toastr.warning('Las fechas no pueden estar vacías');
    } else {
        // Array con URLs para diferentes sets de datos
        const urls = [
            'reportes/pdf_fechas.php',
            'reportes/pdf_evaluacion.php',
        ];

        // Array para almacenar los datos de cada solicitud
        const dataSets = [];

        // Función para realizar una solicitud AJAX por URL
        function fetchData(url, fecha1, fecha2) {
            return $.ajax({
                type: 'POST',
                url: url,
                data: { fecha1: fecha1, fecha2: fecha2 },
            });
        }

        // Realizar las solicitudes en paralelo
        Promise.all(urls.map(url => fetchData(url, fecha1, fecha2)))
            .then(async responses => {
                // Almacenar los datos de cada respuesta en el array dataSets
                responses.forEach(data => dataSets.push(data));

                try {
                    // Crear el docDefinition para un solo PDF usando los datos combinados
                    const docDefinition = {
                        content:  [
                            { text: 'Reporte de actividades de los profesores de LabTec2', style: 'header' },
                            { text: dataSets[0], style:'fechatxt' }, // Segundo conjunto de datos
                            { text: 'Índices de Evaluación e Impacto de la Calidad Investigadora', style: 'boldText' },
                            { text: dataSets[1], style:'normalText' }, // Primer conjunto de datos
                            ],
                        styles: {
                            header: {
                                fontSize: 22,
                                bold: true,
                                color: 'blue',
                                alignment: 'center'
                            },
                            fechatxt: {
                                fontSize: 16,
                                bold: true,
                                alignment: 'center'
                            },
                            boldText: {
                                fontSize: 14,
                                bold: true
                            },
                            normalText: {
                                fontSize: 12
                            },
                        }
                    };

                    // Generar el PDF con pdfMake
                    pdfMake.createPdf(docDefinition).download('Reporte índices de evaluación.pdf');
                } catch (error) {
                    console.error('Error generating PDF:', error);
                }
            })
            .catch(error => {
                console.error('Error in AJAX requests:', error);
            });
    }
}
</script>
<?php include('includes/footer.php'); ?>