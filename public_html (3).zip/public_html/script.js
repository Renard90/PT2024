// Function to generate PDF from HTML content
function generatePdfFromHtml(htmlContent) {
    return new Promise((resolve, reject) => {
        try {
            // Define document definition
            const documentDefinition = {
                content: [
                    {
                        // Convert HTML content to a stack element
                        stack: [
                            {
                                // Convert HTML string to pdfmake's "stack" format
                                text: htmlContent,
                                lineHeight: 1.5,
                            },
                        ],
                    },
                ],
            };

            // Create a PDF document
            const pdfDoc = pdfMake.createPdf(documentDefinition);

            // Generate PDF and return it as a blob
            pdfDoc.getBlob((blob) => {
                resolve(blob);
            }, (error) => {
                reject(error);
            });
        } catch (error) {
            reject(error);
        }
    });
}

// Add event listener to the button
document.getElementById('generatePdfButton').addEventListener('click', async () => {
    const htmlContent = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>PDF from HTML</title>
        </head>
        <body>
            <h1>Hello, World!</h1>
            <p>This is a paragraph in the HTML content.</p>
        </body>
        </html>
    `;

    try {
        // Generate PDF from HTML content
        const pdfBlob = await generatePdfFromHtml(htmlContent);

        // Example: Download PDF
        const blobUrl = URL.createObjectURL(pdfBlob);
        const link = document.createElement('a');
        link.href = blobUrl;
        link.download = 'output.pdf';
        link.click();
        URL.revokeObjectURL(blobUrl);
    } catch (error) {
        console.error('Error generating PDF:', error);
    }
});