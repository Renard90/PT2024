<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate PDF with Styles from HTML</title>
</head>
<body>
    <h2>Generate PDF with Styles</h2>
    
    <!-- Content you want to convert to PDF -->
    <div id="contentToPdf">
        <h1 style="color: blue; text-align: center;">Hello, PDF with Styles!</h1>
        <p style="font-size: 16px;">This is a paragraph with <strong>bold text</strong> and <em>italic text</em>.</p>
        <ul>
            <li style="font-weight: bold;">Item 1</li>
            <li>Item 2</li>
        </ul>
    </div>

    <!-- Button to generate PDF -->
    <button id="generatePdfButton">Generate PDF</button>

    <!-- Include pdfmake library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.70/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.70/vfs_fonts.js"></script>

    <script>
        // Function to generate a PDF from HTML content
        function generatePdfFromHtml() {
            // Get the HTML content to be converted to PDF
            const contentElement = document.getElementById('contentToPdf');
            const content = contentElement.innerHTML;

            // Define document structure for pdfMake
            const docDefinition = {
                content: [],
                styles: {
                    header: {
                        fontSize: 22,
                        bold: true,
                        color: 'blue',
                        alignment: 'center'
                    },
                    boldText: {
                        bold: true
                    },
                    normalText: {
                        fontSize: 16
                    },
                    listItem: {
                        margin: [0, 5, 0, 5]
                    }
                }
            };

            // Manually map the styles from the HTML to the PDF
            docDefinition.content.push({
                text: 'Hello, PDF with Styles!',
                style: 'header'
            });

            docDefinition.content.push({
                text: 'This is a paragraph with ',
                style: 'normalText',
                margin: [0, 10, 0, 10]
            });

            docDefinition.content.push({
                text: 'bold text',
                style: 'boldText',
                margin: [0, 10, 0, 10]
            });

            docDefinition.content.push({
                ul: [
                    { text: 'Item 1', style: 'boldText' },
                    'Item 2'
                ],
                style: 'listItem'
            });

            // Generate the PDF using pdfMake
            pdfMake.createPdf(docDefinition).download('generated_pdf.pdf');
        }

        // Attach the event listener to the button
        document.getElementById('generatePdfButton').addEventListener('click', generatePdfFromHtml);
    </script>
</body>
</html>