<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Date Format</title>
</head>
<body>
    <h2>Capture Dates in DD/MM/YYYY Format</h2>
    <form action="process.php" method="post" id="myForm">
        <label for="date">Date (DD/MM/YYYY):</label>
        <input type="text" id="date" name="date" placeholder="DD/MM/YYYY"><br><br>

        <button type="submit">Submit</button>
    </form>

    <script>
        // Function to format date to DD/MM/YYYY
        function formatDate(date) {
            const day = String(date.getDate()).padStart(2, '0');
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const year = date.getFullYear();
            return `${day}/${month}/${year}`;
        }

        // Event listener for form submission
        document.getElementById('myForm').addEventListener('submit', function(event) {
            // Get the date input value
            const dateInput = document.getElementById('date').value;

            // Parse the input value to a Date object
            const dateParts = dateInput.split('/');
            const day = parseInt(dateParts[0], 10);
            const month = parseInt(dateParts[1], 10) - 1; // Months are zero-based in JavaScript
            const year = parseInt(dateParts[2], 10);
            const date = new Date(year, month, day);

            // Format the date to DD/MM/YYYY
            const formattedDate = formatDate(date);

            // Set the formatted date back to the input field
            document.getElementById('date').value = formattedDate;
        });
    </script>
</body>
</html>